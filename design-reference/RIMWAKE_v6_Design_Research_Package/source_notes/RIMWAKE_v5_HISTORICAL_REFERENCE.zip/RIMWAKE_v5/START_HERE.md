# RIMWAKE v5 — Complete Product Rebuild Handoff

## Read this first

This package contains a **full extended product and visual reconstruction specification** for an ALREADY FUNCTIONING local application, plus a Codex work order. The package is not the running site and does not replace the actual source repository.

### Files in this package

1. `RIMWAKE_v5_Full_Product_Masterplan.md` — complete vision, routes, 28-feature matrix, science integrity, architecture, execution and testing.
2. `RIMWAKE_v5_Design_System_and_Screen_Blueprint.md` — color tokens, typography, grid, desktop/mobile wireframes, animation and 3D implementation rules.
3. `RIMWAKE_v5_Codex_Implementation_Directive.md` — direct execution prompt: audit repository, preserve science, build redesigned app, run screenshot QA and report proof.
4. `RIMWAKE_v5_Audit_QA_and_Research.md` — screenshot critique, source verification, scientific and eligibility corrections and QA record.
5. `RIMWAKE_v5_QA_results.json` — machine-readable static checks and color-contrast results.
6. `references/` — user-provided original long master prompt, four screenshots, and historical v4 plan for Codex context.

### How to use

- Copy/extract **these v5 files into the actual local RIMWAKE project folder** (or mount the folder alongside), not an empty new repository.
- Give Codex **`RIMWAKE_v5_Codex_Implementation_Directive.md` as the kickoff instruction**, and ask it to read the v5 master plan and design blueprint.
- **Do not run v4 kickoff instructions** in parallel with this v5 directive; v4 is historical scope/reference only.
- Require Phase 0 real code audit, a safe baseline branch/preview, then implementation with iterative screenshots.
- If the source directory is missing, Codex should report it rather than generating a replacement website unconnected to your real implementation.
- Protect the current working Vercel release and NASA project submission deadline. Only promote a new build after functional/scientific regressions and mobile visuals pass.

### Most important product decision

**Separate an astonishing cinematic Moon landing page from an extraordinarily usable scientific Explorer.** Make the 2D scientific comparison clear and true, make optional 3D purposeful, and only activate terrain Cause and Robustness Lab when the corresponding source-backed calculations pass validation.

### Status

- Full planning and static document QA: **completed**.
- New website source/code changes: **not performed** here because the working local repo was not available.
- Scientific recalculation and in-browser new UI testing: **not performed**.

### Key official references

- Challenge: https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/
- NASA event/submission: https://www.spaceappschallenge.org/2026/
- JPL Horizons: https://ssd.jpl.nasa.gov/horizons/manual.html
- NASA Goddard terrain: https://pgda.gsfc.nasa.gov/products/78
- NASA CGI Moon Kit: https://svs.gsfc.nasa.gov/4720
- NASA 2026 lunar 3D web models: https://svs.gsfc.nasa.gov/14959/
