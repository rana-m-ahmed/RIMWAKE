# RIMWAKE — The Lunar Horizon Observatory
## Product Masterplan v5.0 — Full Product, Experience Reconstruction, Scientific Expansion, and Competition Release

**Status:** Actionable product/design/scientific execution specification; **NOT** a claim that new features are implemented.  
**Date of planning:** 14 November 2026 (Asia/Karachi).  
**Official challenge:** [NASA Space Apps 2026 — Lunar Landing Site Navigator](https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/).  
**Product identity:** RIMWAKE. Historical concept: HORIZON / CAUSE — The Shadow Witness.  
**Canonical priority:** Preserve functioning science; transform the product experience; make verified causal terrain analysis the signature differentiator when ready.  
**Companion documents:** `RIMWAKE_v5_Design_System_and_Screen_Blueprint.md`, `RIMWAKE_v5_Codex_Implementation_Directive.md`, `RIMWAKE_v5_Audit_QA_and_Research.md`.  
**Evidence boundary:** Screenshots and prior planning documents were inspected. The actual locally developed application repository, runtime, test logs, and scientific artifacts were not provided. The identified private GitHub `RIMWAKE` repository appeared to contain no committed project code at inspection. Therefore all current-code claims below are **screenshot-visible** or **requires-repository-audit**, not tested implementation findings.

---

## 0. The executive design and engineering decision

### 0.1 The product to build

> **RIMWAKE lets a visitor see the Sun and Earth from two places on the Moon, discover meaningful visibility differences over time, and examine the geometric or terrain evidence that explains them.**

This must feel like an **interactive lunar observatory**, not a SaaS dashboard, an academic form, a data chart dumping ground, or a cinematic landing page disconnected from real science.

The product has **three connected layers**:

1. **SEE — Visibility Explorer.** Choose well-described sites and a UTC moment. Inspect synchronized Sun/Earth positions, quantitative angle readouts, a readable horizon, and the Horizon Loom. Geometric-only models are explicitly labeled.
2. **UNDERSTAND — Cause Laboratory.** When the physical terrain pipeline passes its release gates, reveal the actual modeled skyline and trace whether a particular terrain segment obstructs a celestial direction. Link every claim to source and method. Without the validated computation, show a calm, credible unavailable state rather than decorative pseudo-science.
3. **TEST — Robustness Laboratory.** Evaluate supported observer heights, alternative DEM realizations, model resolution and evidence boundaries. Never market ensemble agreement as a calibrated probability of landing-site success.

**The pivotal experience:** "Two sites, one moment, different skies" becomes "Here is the underlying evidence, and here is what changes when the observation setup changes." Neither the UI nor copy may pre-assert that a difference exists until real calculations show it.

### 0.2 Product principles (decision hierarchy)

| Priority | Principle | Design/engineering consequence |
|---|---|---|
| 1 | Truth before spectacle | The active model and provenance are always discoverable; no fake terrain, coordinates, NASA endorsements, event times, or interpolated readings |
| 2 | Exploration before explanation | A visitor reaches an interactive moment in one action from the hero; data tables are progressively disclosed |
| 3 | One visual question per frame | A single primary diagram drives each screen; supporting facts orbit it rather than compete for attention |
| 4 | Dramatic entry, quiet workspace | Cinematic Moon on the landing page; calm, high-contrast instrument design in the Explorer |
| 5 | Consequential motion only | Animations clarify site/time/state transitions, not continually distract or alter scientific readings |
| 6 | Progressive research features | Unsupported Cause/Robustness features remain behind explicitly explained gates; working geometric P0 never disappears |
| 7 | Preserve and refactor, don't reset | No wholesale rewrite of the scientific pipeline or bundler without demonstrated need |
| 8 | Submit reliably | Deployment, demo, README, resource citations and submission checks remain protected even during redesign |

### 0.3 Evidence classification

- **OBSERVED:** screenshot-visible current UI structure, text, site labels, geometric model notice, diagrams and timeline.
- **DOCUMENTED:** prior v2/v3/v4 architecture and user-supplied Master Prompt describe planned behavior.
- **VERIFIED EXTERNALLY:** official NASA challenge, JPL Horizons, NASA Goddard terrain catalog, NASA SVS, W3C and web performance guidance.
- **PROPOSED:** routes, colors, interactions, features, effort estimates and acceptance targets in this v5 plan.
- **UNVERIFIED:** whether current ephemeris pipeline has passed independent validation; coverage of datasets; whether the app is deployed; whether terrain mode works; current source files, assets, package lock and tests.

Do not collapse these categories in progress reports or judge-facing statements.

---

## 1. Diagnosis of the current screenshots

Four supplied PNGs show a pale warm gray canvas, a nearly black green scientific instrument, extremely small monospaced metadata, a long one-page composition, a pair of circular sky plots, an oversized horizontal slider, and a dark timeline panel. The third image duplicates the second composition; the fourth focuses on Horizon Loom.

| ID | Evidence from images | User consequence | Corrective design response | Severity |
|---|---|---|---|---|
| UX-01 | The landing story and large instrument occupy the same scrolling page | No clear beginning, journey or destination; crowded above fold | Separate `/` narrative from `/explore` flagship workspace | Critical |
| UX-02 | Beige + moss green + dark forest dominates almost every surface | Visually reads more like a restrained administrative dashboard than lunar exploration | Replace palette and art direction in entirety; no retained beige/olive theme | Critical |
| UX-03 | Thin, miniature letter-spaced labels dominate controls and metrics | Poor scanability and likely accessibility issues, especially on laptop/mobile | Semantic typography scale and large control/readout hierarchy | Critical |
| UX-04 | Sky plots are comparatively small and visually muted inside giant empty dark regions | The Moon, Sun, Earth and difference are not immediately understandable | Large horizon visualization, celestial markers, expressive A/B comparison and linked readouts | Critical |
| UX-05 | One chart can appear visually blank even while the body readout has a value | Users may mistake off-plot or below-horizon objects for missing data | Explicit below-horizon visual treatment plus accessible summary; never hide state without explanation | High |
| UX-06 | Site dropdowns, time slider, date and event navigation are horizontally dispersed | The user's action hierarchy is ambiguous | Consolidated instrument command bar and contextual shortcuts | High |
| UX-07 | Timeline visually resembles a sequence of colored strips without strong temporal anchors | Scientific pattern exists but narrative/events are hard to read | Rebuild Horizon Loom with day ticks, crosshair, event annotations, accessible states, linked site rows | High |
| UX-08 | "Hypothetical observer / 0 km above reference ellipsoid" is relegated to microcopy | Critical model assumption risks being overlooked | Persistent model-status label and one-tap method explanation | High |
| UX-09 | No immediately visible geographical context or striking lunar image | Visitors don't emotionally or spatially understand the problem | Lunar orbit-to-horizon narrative and selected-site context with truthful coordinates | High |
| UX-10 | Page appears extremely long and single-purpose | Judges may never encounter causal explanation or scientific value within 30 seconds | Purposeful route architecture and one-click guided investigation | High |
| UX-11 | Evidence access is a small secondary link | Scientific trust is hidden behind low-salience microcopy | Purpose-built Evidence Drawer and source chips next to substantive claims | Medium |
| UX-12 | Scientific-visual state uses predominantly color and small text | Unclear color/shape semantics and likely keyboard/mobile friction | Text + icon + texture; keyboard interactions; mobile-native temporal controls | High |

**What should be preserved:** synchronized UTC cursor, both selectable sites, real-valued Sun/Earth readouts, geometric-model candor, 35-day hourly window and optional 10-minute detail, crossing brackets, and the provenance intent. These appear on screenshots, but their logic must still be audited in the repository.

**What must be discarded as a presentation pattern:** one massive dark monolith, low-contrast green microtype, cream-background framing, oversized thin rule separators, generic circles without a readable physical horizon, overlong page stack, and visually similar status labels everywhere.

### 1.1 Baseline audit requirement

Before editing code, Codex shall run the project and collect `/`, `/explore` if present, 1440×900, 1024×768, 768×1024, 390×844, 360×800 screenshots, console errors, current route inventory, DOM accessibility tree, working control inventory, source manifest, app dependencies, network requests and real build/test commands. Save a baseline release/tag and all screenshots. A screenshot alone is insufficient proof of data validity.

---

## 2. Users, jobs-to-be-done, and success measures

### 2.1 Audiences

**Curious visitor (primary):** Understand what the lunar horizon means in under 10 seconds and obtain a satisfying exploratory result without studying an instruction manual.  
**Hackathon judge (primary):** See a real two-site comparison within 30 seconds, understand challenge relevance, scientific source and originality; access evidence without being forced into a long document.  
**Educator/student (secondary):** Manipulate date and site, explore Sunrise/Earth visibility and learn the distinction between geometric visibility and real terrain/shadow/communications.  
**Technically literate mission enthusiast (secondary):** Reproduce sample values, inspect observers, datums, ephemeris quantities and uncertainty.  
**Research reviewer (secondary):** Audit data, frames, source identifiers, numerical cross-checks and limitations.

### 2.2 Core user tasks

1. Identify two documented observation locations and their category (reported landing position, candidate, or hypothetical study point).
2. Answer at a selected **sampled** UTC instant: where are Sun and Earth relative to a defined local horizon?
3. Compare simultaneous Sun/Earth centre visibility at both sites and navigate actual sampled transitions.
4. Explain why a comparison differs **within the model**; distinguish angle changes from physically terrain-caused obstruction.
5. Inspect exact source and computation evidence, and share a reproducible observation reference.
6. When available, test observer height and topography scenarios without losing scientific limitations.

### 2.3 Measurable targets (proposed, not measured)

| Test | Release target | How it is tested |
|---|---|---|
| Time to meaningful exploration | First-time visitor reaches one valid A/B observation within 2 interactions from landing | Usability dry run with 3 people or team proxy; screen recording |
| First impression | Purpose and Explorer CTA visible in first viewport at 1440×900 and 390×844 | Screenshot review |
| Comparison comprehension | A non-expert can identify site, date, Sun state and Earth state within 15 seconds in unmoderated tryout | Timed scenario |
| Scientific consistency | Every numerical readout matches released record for selected site/model/UTC | Automated selectors/fixtures |
| Data unknowns | No missing values rendered as 0 or below-horizon | Fault injection |
| Mobile | No horizontal overflow; critical data visible; touch controls operable | 360/390 widths and real device if possible |
| Accessibility | WCAG 2.2 AA-focused audit, keyboard, focus, noncolor state, reduced motion | axe + manual checks |
| Performance | Target good Core Web Vitals: LCP ≤2.5 s, INP ≤200 ms, CLS ≤0.1 on representative field data; Lighthouse lab values reported separately | Measured on deployed build, no fabricated outcomes |
| Asset efficiency | Main comparison usable without 3D asset, 3D is deferred/lazy | Browser network throttle + WebGL disabled |
| Submission | Public site, public demo, data/AI credits, completed project state confirmed | Anonymous browser + portal screenshot |

---

## 3. Product architecture: routes, navigation and entitlement

### 3.1 Final sitemap

```text
RIMWAKE
/
  Landing: cinematic proposition + one real example + CTA
/explore
  Flagship A/B sky instrument + UTC time + Horizon Loom + Insight Rail
/investigations
  Curated, VERIFIED observation cases; unavailable state if no verified events
/investigations/:caseId
  Guided investigation: observation → evidence → interpretation → change
/cause/:caseId                      [conditional: terrain validation gate]
  Terrain silhouette, ray trace, obstruction source, ideal vs terrain
/robustness/:caseId                 [conditional: sensitivity/DEM gate]
  Observer height, DEM realizations, resolution/coverage caveats
/methods
  Accessible explainer, formal method, sources, validation and limitations
/about
  Project, mission context, team, tooling, credits, data rights
/not-found
  Designed recovery; redirect to Explorer
```

**Navigation:** desktop masthead `RIMWAKE [Explore] [Investigations] [Methods] [About] [Launch Explorer]`, top-right persistent model/status chip inside Explorer; `Cause` and `Robustness` are secondary lab tabs only when enabled. On mobile, hamburger or compact top navigation plus persistent `Explore` action; do not bury the primary action. Back actions preserve site/time/selected model via URL query and store; hide unpublished routes, don't advertise nonworking features as usable.

**Routing:** app shell must preserve direct links on Vercel (history fallback), route-level lazy loading and error boundary. Internal case URLs include a deterministic `caseId` linked to the manifest. Event IDs are source-derived, never invented.

### 3.2 Information hierarchy

- **L0 — Context:** What am I seeing? Which sites, UTC instant and model?
- **L1 — Primary answer:** Is Sun/Earth centre above or below the defined horizon here and now?
- **L2 — Temporal evidence:** When does this change, and what is the sampling limitation?
- **L3 — Physical explanation:** Can validated terrain/accounted assumptions explain a difference?
- **L4 — Provenance:** What data, frames, methods and verification support it?

Every visual screen should reveal L0/L1 without scrolling or jargon. L2 is one scroll or tab below, L3 one intentional click away, and L4 available everywhere in a consistent drawer.

### 3.3 Homepage versus workspace

A high-impact **landing page** earns attention and teaches the question. It does not contain full data-processing controls. The **Explorer** is a controlled information-dense workspace with fixed spatial relationships; the user should not scroll through marketing content to reach site selection. This distinction is non-negotiable.

---

## 4. Page specifications and interactions

### 4.1 `/` — The Gateway (landing)

**Design intent:** A distinct, cinematic, journal-quality lunar science exhibition. Atmospheric lunar imagery; carefully lit Moon; readable typography; visible interaction invitation. More like a high-end science museum installation than an enterprise dashboard.

**Section 1 — Hero (first viewport):**
- Full-bleed midnight blue/near-black space with an enormous physically recognizable lunar sphere or lunar terminator surface. Use NASA SVS LRO data or clearly marked conceptual art. No fake photographic terrain.
- Left: short eyebrow `LUNAR VISIBILITY OBSERVATORY`, headline such as **"On the Moon, where you stand changes what you can see."**, 1–2 sentence plain-language promise, primary `Enter the Explorer`, secondary `See how it works`.
- Right: Earth/Sun directional accents and optional labelled pair of validated observation locations. If a real case has not been released, no numeric prediction, no simulated NASA-derived dot placement; use an artistically framed Moon without site markers.
- Top navigation and a discreet `Data-backed / geometric model` label. No false NASA partnership.
- Controlled scroll cue and optional reduced-motion-safe light movement. A beautiful **static fallback** must work without WebGL.
- **Acceptance:** at 1440×900 and 390×844, headline, why it matters, one CTA and compelling space graphic are visible; CTA routes straight to working Explorer; no forced intro or video playback.

**Section 2 — The paradox:** `The Moon does not share one sky.` Visual side-by-side static or animated horizon tiles. Simple caption explaining horizon effects, never implying true terrain results in P0. One data-backed example may appear if release contains one.

**Section 3 — How it works:** A concise three-stage visual story: **Choose two sites → Move through time → Inspect the evidence**. Use one bespoke animated strip rather than 3 identical feature cards. If terrain mode is validated, fourth `Find the obstruction`; otherwise keep it as an honest research preview, not a functioning CTA.

**Section 4 — A real observation:** One annotated comparison precomputed from the public release. If no difference event is found, show valid data with a truthful observational question. Time/coordinates/link to a case or Explorer are visible. This is the trust anchor.

**Section 5 — The evidence:** Brief visual rail showing NASA/JPL ephemeris, LRO/LOLA terrain *when used*, provenance, model boundaries. No ungrounded NASA logos. Provide `Open Methods`.

**Footer:** independent project, challenge title, source acknowledgments, team/AI credits, method and GitHub/deployment links.

**Narrative length:** 3–5 deliberate sections; not a long scrolling sales deck.

### 4.2 `/explore` — Flagship Observatory Workspace

**Top-level layout at 1440 px:** global 64–72px nav; persistent 72–96px comparison command bar; main investigation stage occupying ~65–72% of remaining width; insight rail occupying ~28–35%; synchronized Horizon Loom full width below; small, beautifully integrated evidence and method access. All values within visual reach, no dashboard-card multiplication.

**Command bar:** selected Site A and Site B, geographic/source badge, single UTC time input + step/event controls, model label, share/copy deep link. Swap site button. Site search includes only manifest-backed entries. Filters for source type and region; never arbitrary unsupported coordinates.

**Primary scientific stage:** Two synchronized **local horizon scenes** aligned to equivalent axes and visual scales. In geometric mode, zero-elevation is a perfectly flat, visibly labelled tangent plane; below-plane Sun/Earth directions remain legible through ghost marks, faded annotation or a secondary sub-horizon region—not silently omitted. In terrain mode, draw only computed skyline horizons and explicitly switch model label. Include precise celestial center azimuth/elevation, a distinctive Sun disc glyph, Earth glyph, hover/focus accessible text, calibrated angle ticks and an optional compass/dome mode. Focus on making the actual difference immediately visible, not on forcing two equal cramped circular plots.

**Insight rail:** headline answer for selected sample, 2 compact site summaries, delta table when meaningful, clear `geometric visibility ≠ actual power/RF link`, action `Explain this`, evidence status chip, `Next supported event` button. No fake ranking, percentages or power scores.

**Horizon Loom:** a zoomable, legible time instrument with rows `{A Sun, A Earth, A Both, B Sun, B Earth, B Both}`, with distinguishable patterns/labels for visible, blocked, boundary and unknown; day ticks, hourly sample cursor, event brackets, filters `All / Sun / Earth / Both`, distinct raw-sample versus inferred-event-range semantics. It must be possible to navigate by keyboard and see a textual event/interval table. A time scrub snaps to released samples. Optional animated motion is visually continuous only if explicitly explained as between-sample illustration, and may never update numerical readings to invented intermediate values.

**Selected-site context:** micro-map/globe thumbnail and source-grounded coordinates; site category and observer model. Historical landing sites are *positions*; do not infer exact deployed hardware orientation, power or terrain height.

**Evidence drawer:** opens from every scientific claim; tabs `Observation`, `Sources`, `Method`, `Limitations`, `Validate`. Shows model, source IDs/links, site coordinate frame and height datum, timestamp, sample cadence, raw/source hashes, release version, exact computation identity, independent verification level, terrain coverage if applicable. A single click can copy case permalink or download validated CSV/JSON within configured rights.

**Mobile:** no miniaturized paired charts. Active Site A/B tab or swipeable compare pane (with keyboard-accessible tab equivalents), sticky time selector, full-width single horizon instrument, always-visible two-line summary of both sites; Horizon Loom below, scrollable with fixed labels; evidence a bottom sheet. Site switching must not reset time. Numeric labels remain ≥12–14px; interaction type ≥16px preferred.

**Acceptance:** Select A/B and time → primary stage, insight rail, metrics, loom cursor and evidence all agree. Site B below-horizon objects are visible *as absence with explanation*, not erased. Deep link restores same observation. At 360px nothing clips. Direct loading works.

### 4.3 `/investigations` and `/investigations/:caseId` — The Guided Story

**Purpose:** Provide a memorable 30-second judging route and a longer learning journey. This page is not a list of fictional scientific discoveries. Cards or editorial story tiles are sourced from a release-specific `cases.json`, containing only cases selected by documented discovery logic. If no verified event is present, show an honest state and direct user to Explorer; do not auto-generate fake dramatic contrasts.

**Five-step case progression:**
1. **Witness:** two documented sites, common UTC instant, synchronized model and clear visual status.
2. **Compare:** exact values and sampled simultaneous visibility; quantify differences only when supported.
3. **Explain:** in P0, differentiate site-dependent local sky geometry and explain the limitations; in P1, show verified terrain obstruction with actual skyline and map link.
4. **Change:** time jump; optionally observer height or site change only if genuine recomputed records exist.
5. **Prove:** open evidence citation/validation card with export/deep link.

Use a **stepper with cinematic, purposeful camera/data transition**, optional keyboard arrows, skip-to-result, deep links to stages, and plain-language breadcrumbs. No narrator audio required. Never force a tutorial on power users.

**Acceptance:** first-time visitor can understand full journey within ~45–90 seconds; judge demo can honestly condense core into ≤30 seconds or ≤7 slides as official portal demands. Data content is immutable across step animations.

### 4.4 `/cause/:caseId` — The Difference Engine (conditionally enabled)

**Visual narrative:** `Same moment → different terrain skylines → obstructing bearing → map trace → conclusion and uncertainty`. Key views:
- Left: topographically correct local 2D skyline with profile angle-versus-azimuth, Sun/Earth marker, clearance angle and selected trace; ideal tangent line as reference.
- Center/right: a **georeferenced** top-down terrain relief or safe 3D regional terrain mesh, selected observer, calculated ray and first modeled obstructing cell/ridge segment. *Only label a named crater/ridge if nomenclature has a valid source and coordinate matching.*
- Lower: numerical explainability panel: observer location/height, celestial direction, skyline angle, margin, modeled intersection distance, source DEM resolution and coverage. Compute site A/B differences for identical UTC/model assumptions.
- A/B scene switch or split view. Clearly differentiate `terrain-blocked` from `geometrically below horizon` and `outside DEM coverage`.
- Shareable `causeId` with release provenance and methodology.

**Activation conditions:** local-plus-long-range terrain horizon coverage; proper Moon frame, ellipsoid/DEM height conversions, verified ray traversal, independent synthetic fixtures, uncertainty/near-zero classification and a reproducible real case. No speculative "the ridge caused it" statements. When gate fails, route displays a research-stage explanation and link to Explorer; no placeholder animation masquerades as a calculated shadow.

### 4.5 `/robustness/:caseId` — Sensitivity and Research Laboratory (conditionally enabled)

**Controls:** observer height scenario (at minimum actual recomputed 1m vs 5m above matched local terrain, if computed); terrain model clone selection with release-defined sample; skyline sample density or alternative far-field model only if precomputed. No arbitrary slider presenting uncomputed results.

**Views:** paired skyline deltas, event interval changes, calculated agreement counts across named DEM clones, uncertainty band where defensible, tabular assumptions and sensitivity summary. Agreement fraction = fraction of *examined model runs* yielding classification; **not** probability of real-world visibility. State sample count; report selection criteria, correlated-model limitations and resolution effects.

**Acceptance:** moving controls reads existing manifest-backed runs; metrics recompute from those runs; no interpolation disguised as science, missing scenarios disabled with reason; run lineage export supported.

### 4.6 `/methods` — A Clear Scientific Explanation

**Narrative mode** (default): three scroll-independent chapters `What is a lunar horizon?`, `What did we calculate?`, `What can we not conclude?` with simplified interactive illustrations and short mathematical explanations. **Technical mode**: exact site coordinates/category, JPL Horizons parameters, frame/time conventions, source descriptions, parser checks, P0 truth table, error budget, terrain methodology, validation references and release list.

**Evidence register:** searchable list of datasets and releases, source URLs, retrieved-at, SHA hashes if available, NASA challenge-resource eligibility status, rights/credits. Dynamic source ID deep links from Explorer. Validation reports must show PASS/FAIL/NOT RUN honestly.

### 4.7 `/about` — Product / Team / Rights

Plain-language rationale, chosen NASA challenge, acknowledgement of NASA/JPL/LOLA data, independent non-NASA status, team, GitHub/release link, development technologies, AI assistance and generated-asset labeling policy, sources/rights. Avoid NASA logos as brand mark. Include contact or issue-report link only if verified and supported.

### 4.8 States that every page must design

Loading / slow network; source unavailable; no cases found; zero ephemeris coverage; sample boundary; unknown body; selected site outside terrain coverage; 3D blocked/unsupported; invalid deep link; source renamed; proof not independently validated; no JavaScript/broken client; reduced-motion mode; keyboard focus inside drawers; unexpected schema version. Each state needs a helpful message and a recovery action; no spinner with no timeout and no dead controls.

---

## 5. Distinctive 3D and scientific visualization architecture

### 5.1 Recommended 3D hierarchy

**3D-1 — Cinematic Moon (P1 design, highest visual ROI):** NASA LRO textured globe built from a sphere + smaller NASA CGI Moon Kit 2K texture rather than a 77–300MB DEM asset on first load. NASA explicitly notes that its CGI color maps are optimized for aesthetics rather than standalone scientific analysis; they are visual context, never the terrain-evidence layer. Camera orbit/terminator lighting is a storytelling layer, not an ephemeris prediction unless synchronized and verified. Surface texture alignment must match site coordinate frame before placing geographic markers. Use a static optimized image/short authored sequence fallback. Make visual quality high through physically plausible lighting, soft Earth-blue rim accents, a dark field with disciplined typography—not particle spam.

**3D-2 — Site Context (P1 after coordinate check):** Click a valid mapped site to slowly focus the Moon toward its position, then transition into Explorer. Do not falsely depict `reported_landing_position` as a precise lander location or as within high-resolution Site01 terrain.

**3D-3 — Local Horizon Theater (P2 scientific):** A limited data-driven terrain scene tied to true height grid; camera at actual modeled observer; optional line-of-sight line and occluding terrain. One click `Show 2D evidence` opens accessible exact counterpart. If coverage is incomplete, visualize mask/boundary rather than hallucinating distant hills.

**3D-4 — Height Comparison (P3):** Compare camera view at two *recomputed* observer heights, overlay clearance-angle changes without distortion; no animation-derived ray values.

### 5.2 Scientific display hierarchy

Primary Explorer uses **SVG/Canvas 2D** for precise axes, ticks, screen-reader alternatives, clear horizon reference and consistent plots. 3D never replaces numerical visibility results. Scientific plot transformations must be documented (e.g. `x=azimuth` for skyline strip; `y=elevation` with zero line). A polar dome is an optional additional view and must correctly map zenith/horizon and below-horizon values.

### 5.3 Visual versus science state

Separate `visualTime` animation from `sampleTimeUTC`. A camera can move between cinematic orientations with labels `illustrative`. Every numerical angle, status chip, event claim and ray must come from released sample data. When render-time camera movement is disconnected from ephemeris, make this obvious; never imply physical precision.

### 5.4 3D performance and fallback gate

| Feature | Acceptance |
|---|---|
| 3D asset | Verified NASA provenance/license/credit; no raw huge meshes on initial render |
| Accessibility | User can skip scene and access equivalent text/2D information |
| Motion | `prefers-reduced-motion` disables orbital/autoplay/camera choreography |
| Performance | Lazy-load after first content or upon intentional interaction; render on demand when idle |
| Scientific correctness | Geographic markers orientation tested against known coordinates and frame |
| Fallback | Optimized static art looks designed and keeps CTA accessible |
| Instrument behavior | Controls work if WebGL context creation fails |

---

## 6. Scientific computing and evidence contract

This is a preservation-and-extension plan. Audit current artifacts before implementing new science.

### 6.1 P0 geometry definitions

**Input source:** JPL Horizons observer ephemerides for Sun (`COMMAND=10`) and Earth (`COMMAND=399`) at explicitly defined lunar topocentric sites. Source: [Horizons manual](https://ssd.jpl.nasa.gov/horizons/manual.html) and [API documentation](https://ssd-api.jpl.nasa.gov/doc/horizons.html).

**Observer:** Moon (`301`), east-positive longitude, lat, altitude above **reference ellipsoid** (not local DEM height). For existing sites shown in screenshots, inspect whether Odysseus/IM-1 and Athena/IM-2 are reported landing coordinates, approximate and source-backed; a `0 km` ellipsoid altitude is a **hypothetical observer** at those horizontal coordinates, not the actual lander. Ensure source category is visible prominently.

**Output:** Horizons airless topocentric apparent azimuth/elevation (`QUANTITIES='4'`), recorded UTC sampling; Sun/Earth centre angles. Reject parsers that silently treat raw Horizons text as structured JSON fields or invert negative elevations. Retain exact query, source time, response metadata and raw SHA.

**P0 states:** `visible`, `blocked`, `boundary`, `unknown`, where `blocked` means **below the geometric tangent plane**, not terrain-blocked. `boundary` depends on a documented numerical/display tolerance; never use rounding as error proof. Combined Sun+Earth logic: definitely blocked when either confidently below; visible only if both visible; otherwise boundary/unknown with explicit semantics. No power generation or RF link claims.

**Sampling:** Existing UI reports 35-day hourly sampling and 10-minute detail; inspect if this is real and available; 35×24+1=841 inclusive samples for uninterrupted hourly grid. A crossing bracket is the interval between opposing sampled signs. Never draw hard edges at exact unsampled event times or imply continuous guaranteed visibility from sparse observations. Data provenance ties site/model/date to immutable release ID.

**P0 validation:** inspect raw Horizons headers and observer parameters; check sample count, UTC time scale, azimuth wrapping and elevation sign, target identities and field ranges; re-query several values to verify parsing; *independent* science check requires a separate correctly configured reference method (e.g. SPICE with aligned lunar frames/aberration). Label checks by level; repeated Horizons query is **not** an independent ephemeris model.

### 6.2 P1 terrain-derived horizon

**Source:** [NASA Goddard 5 m LOLA south-pole DEM product](https://pgda.gsfc.nasa.gov/products/78); site01 Connecting Ridge or another appropriate product if verified. It is published in south polar stereographic coordinates using MOON_ME/DE421 conventions; published 5m pixels are **heavily interpolated** (~90%), and far-field terrain may determine horizon. Published variants include count/uncertainty and up to 100 topographic realizations. 5m grid spacing ≠ 5m measured detail. Source publication is descriptive, not proof that the currently deployed app uses it.

**Terrain computation contract:**
- Verify input GeoTIFF projection, axis, distance units, datum, source frame and sampling mask.
- Convert lunar lat/lon and the ephemeris observer to the exact DEM reference; convert vertical elevation reference correctly. An arbitrary z=0 ellipsoid observer cannot be placed "1m above terrain" without sampling actual topography and datum alignment.
- Evaluate skyline elevation over azimuth with robust ray casting; include observer-earth curvature and near/far-field topography, enough range to avoid false visibility. Use coarse long-range LOLA data only after coordinate/data alignment and provenance.
- Compare ray step/azimuth resolution and horizon cutoff sensitivity; detect gaps/out-of-coverage and return `unknown` when no reliable result.
- Compute `margin = body_center_elevation - terrain_horizon_elevation_at_body_azimuth` with temporal/azimuthal and DEM uncertainty safeguards. For finite-disc visibility, account for the disc extent *over varying horizon angles*; otherwise retain centre-only semantics.
- The modeled obstructing intersection is a *computed* topographic point/segment, not a photo-derived guess; use actual terrain classification and distance.
- Validation includes flat/hill/basin synthetic DEM tests, off-grid observer, azimuth wrap, datum offset, random ray cross-check, resolution and coverage tests. Avoid implying an operationally certified solar/RF analysis.

### 6.3 P2 robustness

Precompute the same time/site/height scenarios with a named subset of alternative NASA terrain models. Record model count, selection, correlated uncertainties, agreement vs ambiguity, and edge-of-detection behavior. Compare true 1-m and 5-m *above local terrain* observers only when recalculated. No probability percentages without calibrated assumptions; any `% of model runs` must be labeled exactly as ensemble agreement.

### 6.4 Lineage and status

**Required lineage chain:** `source → raw request/hash → processing run → release ID → site → observation record → event → terrain trace → visible claim → evidence panel`.

**Status system:** `design_illustration`, `source_reported`, `computed_unverified`, `parser_checked`, `independently_checked`, `terrain_validated`, `unavailable`. A `computed_unverified` readout must not use the same badge as a fully terrain-validated result.

### 6.5 Immutable data schema (logical, not fictitious values)

```ts
type ModelId = 'geometric_center_airless' | 'terrain_center_airless';
type Visibility = 'visible' | 'blocked' | 'boundary' | 'unknown';
type SiteType = 'reported_landing_position' | 'published_candidate' | 'hypothetical_study_point';
interface ObserverModel {
  frame: string; eastLongitudeDeg: number; latitudeDeg: number;
  heightKm: number; heightDatum: string; hypothetical: boolean;
}
interface EvidenceRef { sourceId: string; runId: string; rawHash?: string; methodVersion: string; }
interface BodyReading {
  body: 'sun'|'earth'; utcISO: string; azimuthDeg: number|null;
  centerElevationDeg: number|null; geometricState: Visibility;
  terrainState?: Visibility; evidence: EvidenceRef;
}
interface Observation {
  siteId: string; sampleUTC: string; model: ModelId;
  sun: BodyReading; earth: BodyReading;
  simultaneousState: Visibility; releaseId: string;
}
interface TerrainTrace {
  siteId: string; sampleUTC: string; body: 'sun'|'earth';
  terrainHorizonElevationDeg: number|null;
  modeledOcclusionDistanceM: number|null;
  terrainCoverage: 'complete'|'partial'|'none'; evidence: EvidenceRef;
}
```

Use a schema validator (e.g. Zod if installed), data manifest, runtime compatibility test, typed selectors, explicit missing/null semantics. **No fabricated fixture values may leak to production**; test fixtures live under tests and are labeled synthetic.

### 6.6 Selection of meaningful cases

Scan documented sites and a longer coarse UTC window first; select events algorithmically using predefined criteria and log all searched windows. Refine real transition brackets at shorter cadence. If no real pair difference exists in the available data, the product must show a valid matching/similar outcome and say so. Case cards/hero cannot promise terrain causes before P1 release. Do not cherry-pick time windows then imply general mission ranking.

---

## 7. Engineering architecture and component contract

### 7.1 No unnecessary migration

Audit actual repo and preserve functioning React/TypeScript/Vite code, scientific Python scripts and Vercel configuration. Prefer incremental architecture. Install React Router or use existing routing; R3F/Three only in lazy 3D bundle. Use existing chart/animation dependencies where fit; avoid adding a massive design system package for a weekend project. Prefer CSS variables, SVG scientific plots and a small typed component library.

### 7.2 Recommended module boundaries

```text
src/
  app/                   routes, app shell, route data and error boundaries
  pages/                 Home, Explorer, Investigations, Case, Cause, Robustness, Methods, About
  features/
    site-selection/      search, source/category cards, A/B swap
    time-navigator/      cursor, step, event jumps and canonical UTC
    sky-instrument/      accessible horizon scene, glyphs, axes, text equivalent
    horizon-loom/        time tracks, brushes, transitions and data table
    insight-rail/        derived explanation, not manually written results
    evidence/            provenance drawer, methods/source links and exports
    investigations/      manifest-backed case renderer and guided stepper
    terrain-cause/       release-gated skyline, map and obstruction view
    robustness/          height/DEM comparison controls and reports
    lunar-globe/         lazily mounted 3D + static fallback
  components/ui/         buttons, tabs, drawers, status, inputs, tooltip, skeleton
  design/                tokens.css, typography.css, motion.css, primitives.css
  data/                  schema, manifest loader, typed selectors, source refs
  state/                 central model and URL synchronization
  lib/                   formatting, coordinates, time, accessibility helpers
  tests/                 unit, integration, E2E, visual, accessibility
public/
  assets/                verified NASA textures, encoded stills and attribution
  data/                  immutable release directories and manifest
science/                 existing source-backed numerical pipeline, retained
scripts/                 schema/manifest check, screenshot and release checks
docs/                    implementation, design, science, QA, attribution, submission
```

Keep the existing app root and build commands; this is a conceptual organization, not a demand to move everything at once.

### 7.3 Single source of scientific truth

A canonical state object: `{siteAId, siteBId, sampleUTC, modelId, releaseId, selectedCaseId, sceneMode, activeBody, evidenceDrawer}`. All diagrams, readouts, timeline and URLs use selectors from that state; route transitions preserve selected sites and sampled time. `sceneMode` must not change scientific model implicitly. Prevent stale async requests from changing the displayed release. Reject records whose release IDs differ and show a recoverable message.

### 7.4 Story/design integration

Render symbolic/disclosure content from release metadata:
- If `terrainModelAvailable=false`: no interactive terrain switch; an educational preview can be labeled `Research extension — not available in this release`.
- If `cases=[]`: hide `Start investigation` claims about a discovery and display legitimate exploration instead.
- If `sampleBoundary=true`: explicitly label bracket/uncertainty, don't animate beyond it.
- If `siteType=reported_landing_position`: show historical/site-report caveat and ellipsoid observer assumption.

### 7.5 Agent coordination (Codex)

Worker A: product shell/landing/design system/3D asset. Worker B: Explorer layout/plot/interaction. Worker C: science+manifest/validation. Worker D: independent visual a11y/performance QA. One integrator controls shared state, tokens, routing and release manifest. File ownership, small commits, working checkpoints, and worktree boundaries prevent parallel agents from overwriting shared files. Every worker records actual test commands, screenshots, unresolved issues and change IDs. Avoid duplicate implementation of time selection or site logic.

---

## 8. Feature inventory and full-scope acceptance matrix

| ID | Feature | User value | Input/dependency | Acceptance / release gate | Priority |
|---|---|---|---|---|---|
| F01 | Cinematic landing hero | Immediate emotional orientation | NASA texture or sourced artwork, responsive scene | Loads without 3D; CTA immediately visible; reduced-motion pass | P1-UX |
| F02 | Consistent design system | Coherent premium identity | Tokens, type, components | Screenshots show same scale/palette/glyph semantics | P1-UX |
| F03 | Navigation/routing | Find core work quickly | Router/deep links | `/explore` directly loads; back/URL restore state | P1-UX |
| F04 | Selectable site A/B | Compare locations | sourced site registry | Only supported sites; coordinate category displayed; swap preserves UTC | P0 |
| F05 | UTC time navigator | Explore real samples | ephemeris release | snap-to-sample; accessible keyboard and ticks; no invented instant | P0 |
| F06 | Sun/Earth horizon stage | Understand local sky | released angles and model | az/el consistent, below-horizon states explicit, text equivalent | P0+UX |
| F07 | Numeric summary | Check exact values | observation selectors | 3 decimals only when supported; matching evidence ID | P0 |
| F08 | Horizon Loom | Understand temporal patterns | sampled states | six rows, legends, unknown/boundary, event brackets | P0+UX |
| F09 | Compare insight | Quickly interpret differences | derived states + metadata | no manually fabricated observation claims | P0+UX |
| F10 | Model badges | Distinguish geometry from terrain | release model | always visible in Explorer, click reveals limitations | P0 |
| F11 | Evidence drawer | Build trust | provenance/lineage | source link, raw hash, method, date, verification status | P0 |
| F12 | Scientific method narrative | Learn without jargon | methodology + figures | beginner and technical modes agree | P1-UX |
| F13 | Case gallery | Find meaningful event | verified cases.json | only real cases; missing case truthful state | P1-UX |
| F14 | Guided investigation | Memorable judge journey | site/event data and case steps | 30s demo can show genuine comparison; no forced tutorial | P1-UX |
| F15 | 3D lunar hero | Distinctive entry | NASA LRO texture + 3D | lazy, responsive, opt-out/fallback, rights credited | P1-UX |
| F16 | Globe site context | Spatial orientation | known coordinates/frame | markers transform-validated; never placed by eye | P1-UX |
| F17 | Shareable evidence URL | Revisit/reproduce | route state / release IDs | deep link reconstructs sample and open evidence | P1 |
| F18 | Data export | Reuse real data | verified manifest | export includes metadata/units/UTC/sources | P1 |
| F19 | 3D orbital→horizon transition | Storytelling | scene + valid site | skippable, <= meaningful duration, respects reduced motion | P2-UX |
| F20 | Terrain skyline | Real obstruction context | aligned local/far DEM | synthetic/real tests + complete coverage | P2-science |
| F21 | Terrain obstruction trace | Physical explanation | raycast/horizon + source | reproducible bearing/distance/cell; accurate map trace | P2-science |
| F22 | Terrain vs ideal comparison | Model boundary clarity | both models same observer/time | delta correct; unknown if terrain coverage incomplete | P2-science |
| F23 | 3D local terrain theater | Spatial physical intuition | validated mesh and sightline | scientific parity with 2D skyline and fallback | P2-UX |
| F24 | Observer-height experiment | Test feasible variations | recomputed observer+DEM | only supported height scenarios enabled; correct datum | P3-research |
| F25 | DEM realization sensitivity | Quantify model dependence | named clones | agreement not calibrated confidence; provenance and count | P3-research |
| F26 | Research report / reproducible card | Evidence sharing | validated run metadata | includes limits, source IDs, model and timestamp | P3-research |
| F27 | PWA/offline case bundle | Event-friendly robust demo | service worker and version lock | optional; no stale-release poisoning | P3-optional |
| F28 | Localization | Wider public reach | accurate scientific terms | optional after submission, never time-critical | Post-event |

**Avoid adding:** AI chatbot, fabricated site ranker, arbitrary mission success score, a full global orbital simulator, 3D for every graph, unsourced lunar landing animations, fake sun-power output, audio that does not aid understanding, 100s of landing cards.

---

## 9. Visual design, motion and responsive contract

Full implementation-ready tokens and wireframes are in the companion Design Blueprint. Canonical direction: **Midnight Lunar Observatory** — deep midnight/ink surfaces (`#060917`, `#0C1528`, `#111F35`), sharp off-white (`#F6F8FC`), soft silver secondary (`#B3C0D6`), solar gold (`#FFD18D`), Earth cyan (`#74CDF4`), simultaneous visibility violet (`#C0A8FF`) and danger coral (`#FF8E98`). No beige/olive/navy-green hybrid. Avoid generic gradients and blurry glass panels; atmosphere comes from controlled scientific artwork, not UI ornamentation.

**Typography:** Space Grotesk (editorial headers), Inter (UI/body), IBM Plex Mono (timestamps/angles), tuned with responsive scales. Labels 12–13px minimum on large-screen scientific instrumentation; controls 14–16px; body 16–18px; avoid 9px metadata. Monospaced numerical readouts maintain tabular alignment. Ensure normal text has WCAG-compliant contrast against every surface; sample token pairs are prechecked in QA artifact.

**Motion:** hero reveal 500–800ms once, route 220–320ms, chips/controls 120–180ms, chart marker tween 180–260ms *only between actual samples*, optional camera transition 500–900ms, with reduced-motion alternative. Avoid automatic incessant motion. Story stage transitions narrate where the user came from and what changed.

**Breakpoints:** desktop 1440+, compact desktop 1200–1439, tablet 768–1199, mobile 360–767, tiny 320–359 as graceful fallback. Touch target ideal ≥44px; WCAG 2.2 target-size criterion may permit exceptions but prefer generous targets. Tooltip equivalent by click/focus; keyboard controls for timeline; non-color status patterns for accessibility.

**Screenshots to review:** home top + second fold, Explorer first viewport + Loom, investigation 3 steps, Methods, evidence drawer; 1440×900, 1024×768, 768×1024, 390×844, 360×800. Compare before/after at matching viewports; do not pass QA based on verbal claims.

---

## 10. Execution strategy: preserve submission, then expand rigorously

### 10.1 Release branches / gates

**R0: Freeze the functioning version (immediate).** Preserve Vercel deployment, current state and build commands, branch/tag baseline, copy science manifests and source ledger. Verify domain, full routes, source links. Prepare submission pack separately. Do **not** remove the functioning site while redesigning.

**R1: Radical, coherent visual reconstruction (highest priority).** New design tokens, routing, masthead, landing hero, spacious interactive Explorer, command bar, horizon display, Horizon Loom, insights, responsive behavior, Evidence Drawer. Can be a dramatic improvement without changing scientific model. One outstanding complete journey beats seven unfinished screens.

**R2: Story layer and 3D contextualization.** Lazy NASA LRO Moon sphere, meaningful entry transition, source-aware site pins, authentic case-based guided investigation. Ship only if performance and data-integrity gates pass.

**R3: Terrain science.** Build and validate DEM ingestion, skyline, near/far-field coverage, physical rays and cause cases. The scientific pipeline is a separate deliverable with numerical test reports; don't hide it behind attractive screens.

**R4: Robustness research.** Recomputed height runs, DEM alternatives, sensitivity and exported evidence. After actual validation, integrate UX carefully.

### 10.2 Effort budgets (engineering estimates, not promises)

| Work item | Indicative effort with competent AI-assisted workflow | Risk | Dependencies |
|---|---:|---|---|
| Baseline audit/release safety | 1–2h | Low | actual repository |
| Design system + global shell | 2–4h | Low–medium | baseline |
| Landing hero + authored 3D/static | 3–6h | Medium | asset rights, device budget |
| Explorer composition and plots | 4–8h | Medium | data contract intact |
| Horizon Loom + responsive insights | 3–5h | Medium | released samples |
| Investigation and evidence narrative | 2–5h | Medium | genuine cases |
| Screenshot refinement, a11y, performance | 3–6h | Medium | stable build |
| Terrain computation + validation | 12–30+h | Very high | DEM/frame/far field |
| Robustness experiments | 8–20+h | High | validated terrain |

These are **task engineering estimates** and cannot simply be added as wall-clock totals when parallel workstreams and integration are involved. **Competition deadline is November 15, 2026, 23:59 local event time**; this plan is not a guarantee that full R4 can be completed by then.

### 10.3 Competition-aware path

There are two explicit work lanes:

**Lane A — Protected submit:** preserve existing functioning P0; confirm qualifying NASA resource from challenge tab; meet team eligibility; prepare public demo in approved duration, source/AI ledger, public code, README and project description; deploy a stable commit; have human verify submitted state well before deadline. This lane wins priority over visual additions after freeze.

**Lane B — Product enhancement:** iteratively rebuild UX, capture screenshots, merge validated features. Early gating: land new Home + Explorer + excellent responsive behavior before adding heavy globe or Terrain Cause Lab. Ship to Vercel preview first; switch production only after regression checks. If uncertainty arises, return to the stable R0/previous deployment.

**Minimum meaningful upgrade before submission:** the application looks radically better; the user can use the same scientific data through a coherent Explorer, and the showcase/demo makes the actual difference or valid non-difference understandable. More science is not mandatory to make the UX redesign valuable.

### 10.4 Branch and rollback discipline

`main` remains stable. Work on `experience-v5` or equivalent. Branch from clean baseline. Agent worktrees have file ownership. Commit checkpoints after (i) design system, (ii) Home/Explorer shell, (iii) charts/state, (iv) 3D, (v) QA. Each merge requires build/typecheck/e2e. Keep Vercel preview separate until validated. Preserve old instrument as a temporary internal route or commit for rollback, not in normal navigation. Never replace `public/data/manifest.json` without preserving release lineage.

---

## 11. Acceptance testing and multi-pass QA

### 11.1 Four independent categories

**Science QA:** same selected release/time/site and source all the way to the pixel; compare calculated az/el, angle wrap, negative elevation, unknown/boundary, site category, terrain model label, provenance; synthetic tests and independent methods where claimed.

**UX QA:** visitor starts from landing and completes comparison; all paths have clear affordances; no repeated chart legends buried below fold; each screen has one primary question; no zero-action dead ends; evidence available; mobile switch retains state.

**Visual QA:** screenshots for each target viewport, typography hierarchy, composition, color, negative space, graphic craft, actual moon imagery, icon consistency, motion polish, chart legibility. Do a baseline/round1/round2/round3 comparison; each round must correct a specific finding.

**Engineering QA:** typecheck, build, unit tests, e2e Playwright, axe, throttled network/performance, reduced motion, WebGL unavailable, route deep link, production deployment anonymous access, offline/release mismatch behavior.

### 11.2 Explicit acceptance fixtures

| Test case | Expected outcome |
|---|---|
| Site A is swapped with B while UTC unchanged | All visuals and readings swap coherently, no sample reset |
| Sun elevation -3.762° from released record | Sun clearly labelled below geometric plane; no absent glyph ambiguity |
| Earth value unavailable | `Unknown` visible and no zero/blocked substitution |
| Body near 0° within documented tolerance | Boundary treatment, no confident window assertion |
| Azimuth wraps 359.9° → 0.1° | No wild plotting jump, correct north orientation |
| Site lacks terrain coverage | Cause route/terrain button unavailable with explanation |
| 35-day hourly release has a crossing between samples | Bracket labeled between two timestamps, never exact fabricated crossing |
| Motion disabled in OS | Hero/scene static, content fully reachable, plot values unchanged |
| WebGL disabled | Static lunar image and full 2D Explorer still work |
| User opens release deep link | Site/UTC/model restored or error explains why not possible |
| User presses tab/escape in Evidence drawer | Focus enters, is trapped appropriately, Escape closes and returns focus |
| Narrow mobile 360px | No horizontal overflow and no unreadable 9px labels |
| Public Vercel path refresh `/explore` | No 404; correct app loads |
| Submission uses NASA source from challenge Resources | Exact resource URL recorded in submission ledger, not assumed |

### 11.3 QA severity and release decisions

- **P0 blocker:** broken site/route, false scientific state, leaked fake values, unverified terrain claim, inability to submit, unauthorized NASA branding, missing required credits, inaccessible CTA, mobile content loss.
- **P1 high:** confusing site/time state, charts unreadable, 3D significantly slows app, Evidence Drawer unusable, broken keyboard controls.
- **P2 medium:** inconsistent spacing, less polished microanimation, low-value visual nit.

A passed plan-format audit ≠ passed product science or UX audit. Report results `PASS/FAIL/BLOCKED/NOT RUN` with screenshot/video/log evidence. No blanket "pixel-perfect" claims.

---

## 12. Competition demonstration and release packet

**Official event reference:** [2026 event page](https://www.spaceappschallenge.org/2026/), [GO team submission response](https://github.com/nasa/spaceapps/discussions/1973), [GO team NASA dataset resource requirement](https://github.com/nasa/spaceapps/discussions/1827). Current November 12 guidance specifies a **≤30-second video OR ≤7 slides** (verify final participant portal instructions); project text should describe how NASA data is used and disclose AI. For **Universal Event Global Judging**, a GO Team 2026 response reports **minimum two participants**, unlike some local events; verify team/event status.

**30-second storyboard (only use real implemented features):**
- 0–05 sec: dramatic lunar hero and why the sky changes with observation position.
- 05–11 sec: enter Explorer; A/B sites and exact UTC instant visible.
- 11–19 sec: move to actual sampled contrasting event (or valid no-contrast) and watch synchronized sky / Horizon Loom; identify model.
- 19–25 sec: if Cause passes, show true terrain skyline and obstruction trace; otherwise show honest geometric evidence and method boundary.
- 25–30 sec: source register, NASA data attribution, application value and distinctive experience.

**Required pack:** public live URL; GitHub source as allowed; source-ledger with qualifying resource URL; AI-generated-content and tooling disclosure; dataset IDs/rights; live scientific-status statement; 30s demo or 7 slides; English description; private-window tests; release commit/hash; submission confirmation screenshot. Never claim the project is submitted until portal says so.

---

## 13. Risks and mitigations

| Risk | Likelihood / impact assessment | Mitigation / stop rule |
|---|---|---|
| Design work destroys working geometry | Medium / critical | Freeze R0, typed contract, regression tests on every integration |
| Beautiful 3D gives false scientific impression | High / critical | Narrative-vs-model labeling, independent coordinates for site pins, 2D truth primary |
| Heavy Moon assets delay page | Medium / high | Use 2K texture (NASA CGI Moon Kit) and lazy-loaded sphere; static fallback |
| Terrain missing beyond local DEM tile | High / critical | Add aligned far-field data or mark unknown; no false unobstructed claims |
| Real observations lack dramatic cases | Medium / high | Algorithmic event search, honest null scenario, no fabricated case |
| Animation invents in-between samples | Medium / high | Single sample cursor, snap-on-drag, separate visual tween |
| P0 near-zero classification overconfident | Medium / high | Boundary state, documented tolerance and explicit limitations |
| Mobile scientific plot illegible | High / medium | One-site focus + accessible numeric A/B summary, mobile QA |
| Parallel Codex changes conflict | Medium / high | Worktrees, one app shell/state owner, staged integrations |
| Submission deadline missed | Medium / critical | Protected release and submission lane; no late speculative feature |
| Universal Event solo-team global ineligibility | Depends on actual team / critical for award | Verify GO Team rule, team roster/event immediately |

---

## 14. Source register and factual guardrails

| ID | Source | What it supports | Not proof of |
|---|---|---|---|
| S01 | [NASA Space Apps 2026 challenge](https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/) | Exact project scope, user need for site/date, Sun/Earth horizon | That existing website works |
| S02 | [NASA 2026 competition page](https://www.spaceappschallenge.org/2026/) | Registration, team and project submission windows | User's actual submission status |
| S03 | [GO Team resource rule](https://github.com/nasa/spaceapps/discussions/1827) | Use at least one NASA source from chosen challenge's Resources for Global Awards | The resource tab has already been verified |
| S04 | [GO Team submission instructions](https://github.com/nasa/spaceapps/discussions/1973) | 30-second video or seven slides and submission procedure | Complete portal requirements or user's demo |
| S05 | [GO Team Universal Event clarification](https://github.com/nasa/spaceapps/discussions/1938) | Two-member minimum for Global Judging at Universal Event | User's team type/size |
| S06 | [JPL Horizons manual](https://ssd.jpl.nasa.gov/horizons/manual.html) | Lunar topocentric az/el and observer geometry | Computed or independently validated app data |
| S07 | [JPL Horizons API](https://ssd-api.jpl.nasa.gov/doc/horizons.html) | Query interface | Correct current usage without response inspection |
| S08 | [NASA PGDA high-resolution LOLA](https://pgda.gsfc.nasa.gov/products/78) | South polar 5m DEM, uncertainty, clone ensemble, MOON_ME/DE421 | That terrain mode is available in current app |
| S09 | [NASA SVS Moon models for web](https://svs.gsfc.nasa.gov/14959/) | Credited NASA LRO-based 3D Moon assets and file sizes | Default efficient web delivery |
| S10 | [NASA SVS CGI Moon Kit](https://svs.gsfc.nasa.gov/4720) | Official 2K lunar texture source and higher-res assets | Permission to claim NASA brand endorsement |
| S11 | [NASA Moon Trek](https://trek.nasa.gov/moon/) | Existing lunar geospatial tool and competitive baseline | Novelty of generic 3D Moon navigation |
| S12 | [WCAG 2.2](https://www.w3.org/TR/WCAG22/) | Contrast, semantics, input/focus accessibility | Current app compliance |
| S13 | [web.dev Core Web Vitals](https://web.dev/articles/vitals) | Performance guidance and LCP/INP/CLS thresholds | Current measured speeds |

### Final execution contract

The team must deliver **an actual transformed product**, not only documents: a breathtaking but comprehensible lunar opening, an easier-to-use evidence-backed Explorer, a verified data lineage, a functional and beautiful Horizon Loom, a truthful Cause/Robustness upgrade path, responsive/a11y/performance checks, and a stable public release. No declarative "implemented" claim without files, tests and screenshots. The companion Codex directive spells out the required execution order and proof package.
