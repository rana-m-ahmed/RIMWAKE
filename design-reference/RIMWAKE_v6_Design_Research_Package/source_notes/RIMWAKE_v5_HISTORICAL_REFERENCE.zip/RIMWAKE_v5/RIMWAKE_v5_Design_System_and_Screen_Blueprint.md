# RIMWAKE v5 — Art Direction, Design System, Motion & Screen Blueprint

**Canonical creative direction:** **MIDNIGHT LUNAR OBSERVATORY**.  
**Mood:** dramatic astronomy + architectural precision + premium scientific exhibition.  
**Anti-reference:** beige/olive/forest-green administration dashboard; endless cards; low contrast and tiny type; sci-fi neon sludge; NASA logo imitation; arbitrary 3D planets.  
**Implementation:** this is a visual/product contract for an existing application; it is not an actual screenshot of a rebuilt app.

---

## 1. Art direction: one coherent creative concept

The existing RIMWAKE screenshots flatten a genuinely fascinating subject into a pale canvas and a massive green-black dashboard. The new brand should create a **memorable visual arc**:

**Blackness → distant Moon → illuminated horizon → two sites → quantitative proof.**

Use three tiers of visual drama:

1. **Immersive:** the landing page. A beautifully lit Moon, purposeful composition, restraint in controls and a bold editorial headline. The lunar imagery carries the drama; the UI does not rely on many fluorescent effects.
2. **Instrumental:** Explorer. Midnight-blue surfaces and softly illuminated linework, large legible plots and numbers. Scientific color encodes *Sun, Earth, simultaneous state and uncertainty*.
3. **Forensic:** Investigation/Cause/Methods. Fine geospatial linework, source traces and annotated measurements. A measured editorial look reinforces rigor rather than resembling gaming HUD graphics.

The brandmark should be custom but straightforward: **RIMWAKE** uppercase wordmark with a geometric crescent/horizon glyph created by the team. No NASA meatball, worm, or fictional mission insignia. Optional small lowercase descriptor `lunar horizon observatory`.

### Critical visual rule

**Do not use the old beige background anywhere in the new global experience.** Use dark midnight as the base, with occasional **very restrained** luminous lunar surface/space imagery. Avoid plain black rectangular voids: texture/light should come from the scientific scene, while diagram zones have intentional grouping and scale.

---

## 2. Palette and semantic tokens

### 2.1 Core tokens

| Token | Hex | Use |
|---|---|---|
| `--space-950` | `#060917` | Primary body/hero space |
| `--space-900` | `#0C1528` | Explorer background and scientific zones |
| `--space-800` | `#111F35` | Elevated surface, command bar, evidence drawer |
| `--space-700` | `#172943` | Hover/selected background, selected chart detail |
| `--line-soft` | `#27334A` | Dividers and axes, not oversized rectangles |
| `--text-primary` | `#F6F8FC` | Display and body text |
| `--text-secondary` | `#B3C0D6` | Supporting paragraphs, metadata |
| `--text-muted` | `#8D9BB4` | De-emphasized but still legible labels |
| `--sun-400` | `#FFD18D` | Sun glyph, celestial path, Sun visibility |
| `--earth-400` | `#74CDF4` | Earth glyph and Earth visibility |
| `--both-400` | `#C0A8FF` | Verified simultaneous visibility |
| `--warning-400` | `#FF8E98` | Invalid/error/critical issue; **not** below-horizon by default |
| `--unknown-400` | `#A6B3C4` | Unknown/uncalculated |
| `--focus-ring` | `#FFFFFF` | Visible keyboard focus ring |

**Note:** these are design proposals. Numerically test contrast for actual foreground/background combinations, including translucent overlays and disabled states. Normal text should meet WCAG 2.2 AA 4.5:1 unless the rule explicitly allows exception; chart lines and interactive focus indicators need appropriate non-text contrast. Preliminary solid-color contrast checks for main text, secondary and muted against `--space-950/900/800` all exceed 4.5:1; actual screenshot transparency needs fresh checks.

### 2.2 Scientific colors and non-color encoding

| Science concept | Primary tone | Shape/texture | Accessible label |
|---|---|---|---|
| Sun | Solar gold | Solid circle, warm corona | `Sun · above/below/boundary/unknown` |
| Earth | Earth cyan | Ringed blue disk, subtle earthlight | `Earth · above/below/boundary/unknown` |
| Both geometric | Ultraviolet | Double line or split-circle | `Both centers above tangent plane` |
| Below geometric plane | Desaturated body color + vertical ghost stem | Dashed/outlined glyph | `Below geometric horizon` |
| Boundary | White/gray hatched zone | Diagonal hatch at threshold | `Boundary at sampled instant` |
| Unknown/uncomputed | Gray | Distinct dotted track | `Unavailable / not computed` |
| Terrain obstructed | Coral only with explicit text | Ray ends at actual terrain | `Blocked by modeled terrain` |

**Never use color alone to signify a state.** Negative altitudes must remain readable in the plot and the text counterpart.

### 2.3 Treatment of gradients and glow

- Hero art may use a soft cobalt/blue-purple **spatial light gradient** behind the Moon and a subtle sun-edge highlight.
- Scientific plotting backgrounds stay clean/flat enough for readability.
- A controlled 8–16px halo around selected Sun/Earth glyph may assist focus; glow must not obscure calibrated marks.
- No rainbow accents, glass cards, colorized borders, cyberpunk grids, particle storms or random orbit paths.
- Shadow, blur and translucency must be tested on low-end mobile hardware and under reduced-motion.

---

## 3. Typography and content hierarchy

**Fonts:** `Space Grotesk` for headings/wordmark (licensed web font loaded from verified source), `Inter` for prose/controls, `IBM Plex Mono` for UTC/coordinates/azimuth/elevation. Prefer locally bundled subsets or verified Google Fonts with correct credits. Font loading should not cause significant layout shift.

| Role | Desktop | Mobile | Line height / notes |
|---|---|---|---|
| Hero H1 | clamp(48px, 5.5vw, 88px) | 42–56px | ~1.04–1.1, 2–4 lines maximum |
| Page H1 | 40–56px | 32–40px | ~1.12 |
| Section H2 | 28–36px | 24–28px | ~1.2 |
| Section H3 | 20–24px | 18–22px | ~1.3 |
| Body lead | 18–21px | 17–19px | 1.5–1.65 |
| Body/control | 15–17px | 15–17px | 1.45–1.6 |
| Diagram labels | 13–15px | 13–15px | Explicit accessibility fallback |
| Metadata/mono | 12–14px | 12–14px | Avoid all-caps long labels, preserve letter spacing |
| Scientific headline value | 26–38px | 24–32px | `font-variant-numeric:tabular-nums` |

**Copy guide:** one strong sentence per section; avoid "revolutionizing", "AI-powered", "next generation", and speculative results. Product language should be specific: `Two coordinates. One UTC instant. Two different views of the sky.` is stronger than generic technology claims. Explain `geometric tangent plane` plainly once, then allow `Learn more`.

**Microtype reform:** old screen uses many 9–11px uppercase tags like `SYNCHRONIZED UTC`. Preserve precision, not microscopic size. Keep legal/source text >=12px and body explanation >=15px wherever practical.

---

## 4. Spatial layout system

### 4.1 Dimensions

- Max landing copy width: 1160–1280px; hero edge-to-edge art can occupy full viewport.
- Main data workspace max width: 1540–1680px with 32–48px desktop side margins; accommodate 1440px without excessive blank gutter.
- Spacing base 4px; scale 4/8/12/16/24/32/48/64/96; no arbitrary 37px paddings.
- Radius: 6–10px on technical controls; 14–20px on major intentional surfaces only; avoid a wall of generic round cards.
- Top nav: 68–76px desktop, 60–64px mobile.
- Command bar: ~80px desktop; compact multi-row mobile with safe touch targets.
- Chart stage min height: ~500px desktop; ~340px mobile per focused site with clear instrument status.
- Strong 2D stage first; optional 3D is a separate view or hero background.

### 4.2 Responsive layout rules

| Viewport | Structure | Primary scientific interaction |
|---|---|---|
| ≥1440 | 8-column stage + 4-column insight rail; full-width loom | Simultaneous A/B, evidence right drawer |
| 1200–1439 | 7+5 or 8+4 proportions, compact spacing | A/B still visible; insights reduce prose |
| 768–1199 | Stack main stage and insights; 2-pane plots if legible | Timeline full-width and readable, no tiny sky domes |
| 390–767 | Single active-site view with sticky A/B toggle + permanent comparison summary | Full-width horizon, touch-safe date/step, drawer as bottom sheet |
| 320–389 | Strict single column; short labels, no crowding | Site A/B segmented toggle and numeric summary; chart fits width |

---

## 5. Complete screen wireframes

### 5.1 Landing at desktop 1440×900

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ RIMWAKE     Explore     Investigations     Methods     About      [Launch →]│
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  LUNAR HORIZON OBSERVATORY             ┌─────────────────────────────────┐  │
│                                       │                                 │  │
│  On the Moon,                         │       [MOON / source-verified    │  │
│  where you stand                      │        LRO textured sphere]     │  │
│  changes what you see.                │          · subtle halo          │  │
│                                       │                                 │  │
│  Compare the Sun and Earth            │   Observer markers ONLY if      │  │
│  from two lunar locations,            │   aligned to verified coords    │  │
│  in one shared moment.                └─────────────────────────────────┘  │
│                                                                              │
│  [Enter the Explorer →]  [See how it works]                                   │
│                                                                              │
│   JPL ephemerides  ·  sampled UTC data  ·  source-linked evidence            │
│                                                               scroll ↓      │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Visual notes:** moon art should be larger than typical product illustration (cropped beyond hero right/bottom edge), cold rim-light and a disciplined dark gradient. Avoid throwing 3 card widgets into hero. The actual site data and live preview appear **below** the hero, not as tiny overlaid readouts that clutter the art. CTA stands out as one concise light-toned button; secondary text link is subdued.

### 5.2 Explorer at desktop 1440×900

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ RIMWAKE   [Explore]   Investigations   Methods          EVIDENCE ●  P0 model│
├──────────────────────────────────────────────────────────────────────────────┤
│ A [Odysseus ▾]   ⇄   B [Athena ▾]    UTC [04 Dec 2026 08:00] [◀] [▶] [Event]│
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  TWO SKIES / SAME MOMENT                            THE OBSERVATION          │
│  ┌─────────────────────────────────────────────┐    ┌──────────────────────┐ │
│  │ Site A                      Site B           │    │ Sun · A: BELOW      │ │
│  │ [large paired, ALIGNED horizon charts]      │    │ Earth · A: VISIBLE  │ │
│  │ visible 0° line; Sun and Earth labelled     │    │ Sun · B: BELOW      │ │
│  │ below-horizon glyph appears below zero      │    │ Earth · B: ...      │ │
│  │ correctly; AZ/EL readouts accessible         │    │ Model: geometric     │ │
│  └─────────────────────────────────────────────┘    │ Explain / Evidence    │ │
│                                                     └──────────────────────┘ │
│  HORIZON LOOM · DEC 2026                         [Sun] [Earth] [Both] [10m]    │
│  ┌───────────────────────────────────────────────────────────────────────┐   │
│  │ day marks     |       |        cursor       |        |               │   │
│  │ A Sun         ░░░█████░░░ ...                                       │   │
│  │ A Earth       ██████████░ ...                                       │   │
│  │ A Both        ░░░████░ ...                                          │   │
│  │ B Sun / Earth / Both        ...                                     │   │
│  └───────────────────────────────────────────────────────────────────────┘   │
│  MODEL: geometric center / terrain excluded   [Read scientific method →]     │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Visual notes:** sketch represents **layout only**, not fabricated science. Text placeholders like `BELOW` are labels from a hypothetical rendering state and must be populated from real records; if demo uses 04 Dec 2026, numbers must come from real data. The central stage visually dominates (bigger than the old small circles). Use aligned horizon strips or upgraded sky-dome charts with clear captions. For actual appearance, horizontal horizon is preferred primary; 3D Moon is a context toggle or small location element, not a science substitute.

### 5.3 Mobile Explorer at 390×844

```text
┌───────────────────────────────────┐
│ RIMWAKE                 ☰   ⓘ     │
├───────────────────────────────────┤
│ SAME MOMENT · TWO SITES           │
│ [Site A ◉]   [Site B ○]  [Swap ⇄] │
│ Site A: Odysseus · position type  │
│                                   │
│ [FULL-WIDTH horizon plot]         │
│                                  │
│ Sun: below  •  Earth: above      │
│                                   │
│ UTC   [04 Dec 2026 08:00]         │
│ [Prev]  [time scrubber]  [Next]   │
│                                   │
│ COMPARISON SUMMARY                │
│ A: Sun … / Earth …               │
│ B: Sun … / Earth …               │
│                                   │
│ [View Horizon Loom ↓]            │
│                                   │
│ [Evidence and limitations ↑]     │
└───────────────────────────────────┘
```

No layout may rely on horizontal scrolling across scientific control groups. A timeline itself may pan within a labelled, accessible area, but surrounding page must not overflow. Any swipe gestures must have visible button equivalents.

### 5.4 Investigation story layout

- Fullwidth stage header: `CASE 01 · SOURCE-VERIFIED` only if case exists.
- Step indicator `01 OBSERVE / 02 COMPARE / 03 EXPLAIN / 04 TEST / 05 VERIFY` with progress and skip.
- Science stage ~65% and narrative text ~35% on desktop; one screen at a time on mobile.
- A step animates camera from Site A to Site B **without inventing** intermediate site data; observation values change only after arrival at supported site/time.
- At `EXPLAIN`, show cause only when terrain verified. P0 uses true site-dependent angular geometry; avoid fake obstruction animation.
- At `VERIFY`, reveal beautiful source card and method boundaries.

### 5.5 Cause Laboratory

```text
┌──────────────────────────────────────────────────────────────┐
│ CAUSE / Site A to B / supported instant / terrain model     │
├────────────────────────────────┬─────────────────────────────┤
│ SKYLINE / angle vs azimuth     │ RELIEF MAP / georeferenced   │
│ 0° ideal tangent baseline      │ site ⊙ → trace — × ridge    │
│ modeled terrain profile        │ coverage mask visible       │
│ Sun and Earth rays / margin    │ switch A ↔ B                │
├────────────────────────────────┴─────────────────────────────┤
│ INTERPRETATION: why model says visible, blocked or unknown   │
│ Bearing · distance · elevation · DEM · validation · export  │
└──────────────────────────────────────────────────────────────┘
```

If `terrainCoverage !== complete`, large clear `insufficient model coverage` treatment takes precedence. Nothing suggests the location of a real obstructing ridge without actual calculation.

### 5.6 Evidence Drawer

- Desktop side panel 420–520px; mobile full-height sheet/modal with usable close/focus.
- Tabs: `This observation`, `Sources`, `Model`, `Validation`, `Limitations`.
- Example sections: `Time: sampled UTC`, `Observer: 0 km above reference ellipsoid, hypothetical`, `Body: Sun centre`, `Horizons quantity: apparent airless AZ/EL`, `Scientific status: parser checked`, `NASA source / date`, `run ID and raw hash`, `export / copy link`.
- If a field is missing, say `Not reported`, not an empty bordered card.
- Clicking `Read method` opens route with preserved observation context.

---

## 6. Component hierarchy and interaction semantics

**Global:** `AppShell`, `GlobalNav`, `Footer`, `ModelStatusChip`, `RouteTransition`, `SkipLink`, `OfflineNotice`, `ErrorBoundary`.

**Scientific:** `StudySiteSelector`, `CompareSitesToggle`, `UTCNavigator`, `EventJump`, `SkylineInstrument`, `BodyMarker`, `AngleReadout`, `SiteComparisonSummary`, `InsightNarrative`, `HorizonLoom`, `SampleBoundaryLegend`, `EvidenceDrawer`, `ProvenanceTag`, `ValidationLevel`.

**Immersive:** `MoonHeroScene`, `MoonStaticFallback`, `SitePin3D`, `CameraTransitionController`, `MiniLocationGlobe`, `TerrainReliefScene`. Every immersive component must declare **whether its geometry is narrative or quantitative**.

**Story:** `InvestigationIndex`, `CaseFeature`, `CaseStepper`, `ObservationReveal`, `CausalEvidence`, `ScenarioCompare`, `SourceProof`.

**Accessible data equivalents:** `ObservationDataTable`, `TimelineEventTable`, `TerrainTraceTable`, `SourceList`.

### Buttons, controls and affordances

- Primary CTA filled high contrast; one per section.
- Secondary button ghost/outline; consistent hover + focus.
- Selected site control shows *full meaningful name* and location classification, not a cryptic code alone.
- Model status is always visible and opens a short definition.
- UTC step controls have tooltip `Previous sample (60 min)`; allow `Shift+Arrow` for larger skip only if supported and discoverable.
- Every chart color has corresponding legend text, shape and a full accessible readout.
- Dragging isn't the only way to change time; mouse, touch, keyboard, plus-minus controls and direct sample selection supported.

---

## 7. Motion design specification

### 7.1 Motion tokens

| Motion type | Duration target | Easing | Rule |
|---|---:|---|---|
| Hover/press | 100–160ms | ease-out | Small tactile response only |
| Selection | 160–240ms | ease-out | Focus ring remains visible |
| Drawer/overlay | 240–320ms | standard | Focus managed, no confusing parallax |
| Route transition | 220–360ms | ease-in-out | No full-screen flash or forced delay |
| Hero reveal | 500–850ms | cubic-bezier(.2,.8,.2,1) | Once on entry; optional if reduced motion |
| Moon camera shift | 500–900ms | damped, deterministic | Only when meaningful; avoid motion sickness |
| Scientific sample change | 120–240ms | direct | Values snap to actual sample, glyph can move but is labelled display transition |
| Horizon Loom selection | 120–220ms | direct | Cursor precisely at released timestamp |

### 7.2 Hero sequence (not a mandatory splash)

0.00s: navigation and CTA are **already interactive**. Moon asset has placeholder still.  
0.15s: moon luminance/terminator emerges softly; headline fades/raises by ≤16px.  
0.45s: Earth-blue accent line traces a single small arc, optional.  
0.70s: subtle evidence microtext appears.  
Later: no forced continuous camera motion; optional user-controlled drag/orbit with clearly labelled affordance.

**Never** automatically scrub through scientific time while pretending readouts correspond to live celestial observations. An illustrative hero may animate camera/orbit only when disclosed.

### 7.3 Reduced-motion and visual safety

- `@media (prefers-reduced-motion: reduce)` immediately disables decorative camera, parallax and long entrance transitions.
- User can skip 3D; scroll animations not required to access content.
- Avoid flashes, strobe-like stars and rapid chart transitions.
- No video audio autoplay.

---

## 8. 3D engineering specification

**Asset selection:** Use the [NASA SVS CGI Moon Kit](https://svs.gsfc.nasa.gov/4720) `lroc_color_2k.jpg` (~447KB listed) on a geometrically correct sphere as the default web-optimized lunar visual. NASA's [2026 Web 3D Moon Models](https://svs.gsfc.nasa.gov/14959/) include a ~13.2MB `moon_small.glb` that is a possible optional enhancement, **not** the default critical asset. The 77.7MB+ topo versions are not suitable as first-load critical assets. Verify current source files/licensing and credits when downloading. NASA notes the CGI color texture is for aesthetics rather than scientific topographic analysis; do not derive site elevation, ray obstructions or measurements from this texture.

**Scene:** one sphere mesh, physically plausible directional sunlight, custom rim-light if appropriate, dark atmospheric vignette. Site-marker placement only after verifying texture prime meridian orientation, Moon reference frame, lat/lon transform. No spacecraft models or lander pins positioned by aesthetic guesswork. Use canvas `aria-hidden` only when equivalent accessible explanatory text exists.

**Performance:** lazy `import()` for Three/R3F and globe; limit pixel ratio on mobile, e.g. `Math.min(devicePixelRatio,1.5)` if tests justify; render on demand or throttled; pause offscreen; no giant post-processing shader chain. Asset budgets from actual deployed build, not guessed. Preserve non-WebGL fallback.

**Progressive enhancement:** fallback visual is a composed moon image sourced from NASA (with source credit) and clear Earth/Sun overlay labeled *illustration* if not physically computed. The site must function identically without the canvas.

**Validation:** screenshots / WebGL enabled and disabled, cold-load bandwidth 4G/slow, mobile battery/performance, keyboard equivalence, focus and reduced-motion. Test source/model orientation using at least two known non-collinear lunar coordinates before geographic pin release.

---

## 9. Art direction quality rubric and hard failure patterns

Each design round is rated 0–5 with recorded screenshot evidence; no self-awarded 5 without comparable visual evidence.

| Category | Weight | Excellent if… | Fail if… |
|---|---:|---|---|
| First impression / hero | 18 | Composition memorable; purpose/CTA immediately clear | Looks like a generic SaaS or one long dashboard |
| Spatial hierarchy | 18 | One hero chart and obvious primary action per screen | Everything equally emphasized or microtype dominates |
| Scientific visualization | 22 | A/B/UTC/status obvious; units+axes clear; below-horizon explicit | Scientific markers disappear or misleading terrain |
| Interaction ergonomics | 14 | Site/time/evidence intuitive, keyboard and mobile workable | Controls scattered; hidden actions; dead buttons |
| Color/type craft | 12 | Consistent semantics, contrast, legibility | Beige/olive retained, arbitrary colors, 9px labels |
| Motion/3D intentionality | 8 | Adds context without delaying reading | Heavy decoration, orbit drift, fake scientific trajectory |
| Source/accessibility trust | 8 | Evidence readily available and text equivalents present | Model label hidden or 3D required |

**Acceptance target:** internal design quality ≥85/100 with no scored category below 3/5, independently reviewed by screenshots; numeric rubric is internal management, not a NASA score. More importantly, all release-blocking science and usability tests must pass.

### Automatic anti-template inspection

Codex reviewer must search and flag: duplicated card layout >3 across unrelated sections, same radius everywhere, large disconnected whitespace, headings centered by default, random gradients, fluorescent green, generic icons instead of bespoke body glyphs, marketing fluff, unlabeled axes, mock numbers, animations without purpose, tiny uppercase microcopy, two+ competing CTA buttons, timeline without UTC readout, misuse of NASA logos.

---

## 10. Visual QA procedure

**Pass A — Establish baseline:** existing screenshots plus in-browser captures and DOM snapshots. Record viewport/route/date/model.  
**Pass B — Layout:** after first redesign, capture all key routes at 1440×900 / 768×1024 / 390×844 / 360×800; mark at least 5 specific defects and fix them.  
**Pass C — Science-state visual review:** force visible, blocked, boundary, unknown, offline, no cause dataset and WebGL unavailable; inspect each state.  
**Pass D — User-flow review:** record landing → select sites → step time → compare → evidence → methods; measure number of clicks and whether context stays intact.  
**Pass E — Final polish:** compare paired baseline/after images; revisit overly empty regions, logo, texts, chart labels, animation timing; verify build and Lighthouse/axe as actual values.  
**Pass F — Adversarial:** take screenshots at the smallest viewport, most text-dense site names, negative elevation, wide UTC date strings and error states; assess unexpected layout/overflow.

Test fixtures can be synthetic only in test environment; production screenshots used to support science claims must come from genuine release records and be identified accordingly.

---

## 11. Exact design handoff items

Codex must create or update:

1. `docs/PRODUCT_MASTERPLAN.md` incorporating project-specific source audit, not a duplicate generic template.
2. `docs/DESIGN_SYSTEM.md` with final screenshot-tested tokens, fonts, components and motion details.
3. `docs/UX_REDESIGN_AUDIT.md` with baseline, before/after screenshots and fixes.
4. `docs/SCIENCE_STATUS.md` with claim-level status and method limitations.
5. `docs/FEATURE_STATUS.md` with `WORKING / PARTIAL / NOT IMPLEMENTED / BLOCKED`, not aspirational prose.
6. Actual application code, accessible routes, tests, and deployed preview instructions.
7. A screenshot contact sheet covering desktop, tablet and mobile; screenshots captured from running app, not generated concept art.

**Do not accept** an implementation that merely swaps CSS colors, adds a giant canvas to the old page, or converts the instruments into generic cards. The entire presentation architecture must change while the verified scientific state remains intact.
