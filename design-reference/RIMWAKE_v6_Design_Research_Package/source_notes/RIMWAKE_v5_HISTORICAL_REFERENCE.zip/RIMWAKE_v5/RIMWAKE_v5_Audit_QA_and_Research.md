# RIMWAKE v5 — Evidence-Based Audit, Research Verification, and QA Report

**Scope:** Review of four supplied screenshots, 792-line user Master Prompt, prior HORIZON / CAUSE v2/v3/v4 planning artifacts, public NASA/JPL/standards sources, and the v5 document package.  
**Date:** November 14, 2026.  
**Important:** This is an **audit of the provided visual evidence and implementation specifications**, not a browser audit of the existing source code. No user-local runtime or verified app build was available in this session. The identified private GitHub repository with matching title was reported empty in its metadata; it cannot substitute for the working local codebase.

---

## 1. Executive audit verdict

**Previous UI:** high-priority full reconstruction, not cosmetic retouching.  
**Previous scientific intent:** retain; current screenshots disclose a center-of-disc geometric horizon model and hypothetical reference-ellipsoid observers.  
**New direction:** Midnight Lunar Observatory, distinct `/` landing and `/explore` workspace, large paired horizon stage, source-driven story and gated 3D/terrain.  
**Scientific upgrade:** P1 terrain and P2 robustness remain CONDITIONAL; neither screenshots nor plans prove implementation.  
**Submission safeguard:** preserve working R0 baseline and deployable release while rebuilding; owner must confirm actual NASA team/resource and submission status.

### Observed UI defects (screenshots, not code)

| ID | Confidence | Visual evidence | Severity | Required fix |
|---|---|---|---|---|
| V-01 | High | Nearly all top-level UI uses beige `~#E9E9DF` and forest `~#101A15`; flat, muted hierarchy | Critical | Distinct cinematic blue-black palette, deliberate contrast/art |
| V-02 | High | Homepage merges hero, controls and very long scientific widget | Critical | Real landing and Explorer routes with purposeful nav |
| V-03 | High | Diagram forms a relatively small plot inside huge dark zone | High | Scientific plot is hero of Explorer, aligned A/B instruments |
| V-04 | High | 9–12px-style uppercase metadata and subtle linework | High | Readable type hierarchy, minimum chart label and control sizes |
| V-05 | High | Site B sky plot appears visually empty at sampled time | High | Explicit below-horizon/unknown glyphs and text, no silent disappearance |
| V-06 | High | Entire time navigator is a long slider with disparate date controls | High | Unified UTC command bar; accessible sample controls and event jump |
| V-07 | High | Loom has long colored strips, sparse axes, no event storytelling | High | Distinct six-row timeline, labels, day/hour ticks, linked cursor, event brackets |
| V-08 | High | Model caveat is miniature in footer | High | Persisted model badge with one-click method explanation |
| V-09 | High | No dramatic lunar geographic identity or 3D scene | High | NASA-credited lunar hero and contextual globe, optional/lazy |
| V-10 | Medium | Evidence buried as thin link; source panel not shown | Medium | Purpose-built evidence drawer; actual panel must be inspected in repo |

**Pixel observation:** automated thumbnail-sampling identified the background colors near RGB `(233,233,223)` and `(16,26,21)` as by far the most frequent screenshot colors; this is a directly measured visual property, not a design preference claim. The source screenshots are 1516–1533px wide and ~728–730px tall. All numerical UI-quality ratings remain heuristic until live usability testing.

### Preserve positives

Current visible interface already labels model scope (`Geometric horizon · terrain excluded`), marks observers as hypothetical, shows UTC, includes actual numeric az/el readouts, has a 35-day scan and crossing brackets, and includes an evidence/method link. These labels demonstrate an intent toward transparency; they do **not** independently verify accurate source computation.

---

## 2. External research and validated implications

| Source | Verified finding | Implementation implication | Restriction |
|---|---|---|---|
| [Official NASA 2026 challenge](https://www.spaceappschallenge.org/2026/challenges/lunar-landing-site-navigator/) | The brief asks to compare lunar landing sites and dates by Sun/Earth positions relative to horizon | Make site/date/sky comparison primary; no need for fake spacecraft mission planner | Challenge does not certify operational power/comms |
| [NASA 2026 event page](https://www.spaceappschallenge.org/2026/) | Submission opens November 14 at 09:00 and closes November 15 at 23:59 local time; completion is path to participant certificate | Freeze/submit early; preserve current working build | Actual portal may add fields to verify |
| [NASA GO Team #1973](https://github.com/nasa/spaceapps/discussions/1973) | Demonstration video ≤30 seconds or ≤7 slides; summarize NASA data and disclose AI | First-time-visitor 30s case; protect demo prep | Verify current guide/portal version |
| [NASA GO Team #1827](https://github.com/nasa/spaceapps/discussions/1827) | At least one qualifying NASA dataset in chosen challenge's Resources for Global Awards | Resource verification is an eligibility blocker | Exact Resources tab content not inspected for this team |
| [NASA GO Team #1938](https://github.com/nasa/spaceapps/discussions/1938) | Universal Event teams require minimum two participants for Global Judging; only applies to Universal Event | Check team roster and event type ASAP | Doesn't establish actual team status |
| [JPL Horizons manual](https://ssd.jpl.nasa.gov/horizons/manual.html) | Airless topocentric apparent azimuth/elevation quantity 4, east-positive Moon longitude; reference ellipsoid elevation | Label imaginary `0 km ellipsoid` observers accurately | Re-query not independent ephemeris validation |
| [NASA Goddard PGDA product 78](https://pgda.gsfc.nasa.gov/products/78) | 5m polar LDEM, MOON_ME/DE421, interpolation ~90%, error maps and clones | Terrain science needs strong datum/far-field/uncertainty gates | Local tile is not complete lunar horizon by itself |
| [NASA Moon Trek](https://trek.nasa.gov/moon/) | NASA already offers 3D globe and Moon geospatial tools | 3D globe alone is not a novelty claim | Do not suggest merely rendering a Moon is scientific differentiation |
| [NASA SVS 14959](https://svs.gsfc.nasa.gov/14959/) | Official 2026 LRO-derived GLB models, ~13.2MB small and much larger topo files | Optional 3D; optimize size and lazy-load | Source credit required, don't claim asset is tiny |
| [NASA SVS 4720](https://svs.gsfc.nasa.gov/4720) | Official LRO-based color maps, 2K JPEG around 447KB | Preferred lightweight sphere texture; NASA says CGI color maps are aesthetic, not science | Texture orientation must be checked for site pins; not valid quantitative DEM |
| [WCAG 2.2](https://www.w3.org/TR/WCAG22/) | AA text contrast 4.5:1 generally; input, focus and non-color cues necessary | Build accessible controls and alternative chart tables | A palette-only contrast pass does not prove AA conformance |
| [web.dev Core Web Vitals](https://web.dev/articles/vitals) | Good targets include LCP ≤2.5s, INP ≤200ms, CLS ≤0.1 at 75th percentile | Optimize above-fold art and defer 3D | Lab Lighthouse scores and field CWV are distinct |

### Critical new finding versus earlier planning

Earlier plans referred to a solo-led/solo Universal Event strategy. Official 2026 GO Team clarification indicates **Universal Event needs at least two people for Global Judging**, although local-event rules differ. RIMWAKE's full development could still produce a participant certificate, but award eligibility is partly an **account/team requirement**, not a UI feature. Confirm actual team and event, do not assume.

### Science-specific corrections

1. A negative celestial elevation is a valid *below geometric horizon* sample and **must remain visualized** even if a conventional polar sky dome only shows the upper hemisphere.
2. Horizons Moon lat/lon with height 0km above reference ellipsoid does not describe a lander antenna actually resting on terrain. Historical mission names do not remove this limitation.
3. Don't call a 5m DEM pixel a 5m measured terrain point; NASA notes extensive interpolation. A local DEM tile cannot establish complete clear line of sight if the far field is unmodeled.
4. An exact horizon-crossing second cannot be inferred from a mere hourly sign change; display the bracket unless numerically refined/validated.
5. Repeating Horizons queries checks API/parser reproducibility, **not independent astronomy**. Independent model claims require aligned SPICE/other model settings and measured comparison.
6. A smooth animated Moon camera or celestial icon must not update the quantitative scientific record to invented in-between samples.
7. Earth centre above tangent plane does not prove direct-to-Earth RF service; Sun centre above does not prove solar power generation. Finite discs and terrain effects matter.
8. Missing data and unsupported terrain coverage must be `unknown`, not coerced to `blocked` or `0`.

---

## 3. Decisions and tradeoffs documented

| Decision | Chosen | Rejected | Why |
|---|---|---|---|
| Brand | RIMWAKE | Renaming again | Already in working screenshots, easy continuity |
| Design | Midnight Lunar Observatory | Beige/olive administrative style | Stronger emotional identity, science-state contrast |
| Routes | Dedicated Landing, Explorer, Investigations, Methods and conditional labs | Single mega-page | Clear user goal per surface, better judge journey |
| Main plot | Accessible calibrated 2D skyline/paired horizon | Giant speculative 3D terrain | Numeric fidelity, comprehension, performance |
| 3D | Lightweight lazy NASA sphere + fallback | 77–300 MB topo GLB at first paint | Efficiency and optional access |
| Visible case | Manifest-backed real event | Hero with invented "dramatic" observation | Evidence integrity |
| Terrain | Verified ray + near/far field + coverage masks | Place random ridge mesh under a sun ray | Scientific validity |
| Animation | State and narrative choreography | Constant orbit/particle show | Reduced cognitive load and mobile cost |
| Science code | Preserve verified core | Rebuild from scratch merely for design | Regression risk |
| Submission | Protect stable R0 separately | Force late unverified features | Deadline risk |

---

## 4. Open questions Codex must resolve from actual repository

- What is the actual Git origin/path? The similarly named private GitHub repository appeared empty at inspection; local working source was not attached. **No actual repository QA or implementation edits could be performed here.**
- Which libraries, routes, CSS frameworks, animation tools and data schemas exist? Which feature is actually functional?
- What exact sources establish IM-1 and IM-2 coordinates? Are they approximate landing positions and what frame do they use?
- Was the 35-day scan fetched from actual JPL Horizons with correct observer parameters? What runs have independent scientific validation?
- What is the asset license/credit ledger, and did any images come from AI generation?
- Are qualified NASA Resources-tab datasets already used, and which are they?
- Is current Vercel deploy publicly accessible? Do direct route refreshes work? What are measured mobile load results?
- Is the event Universal or local, and is the roster eligible for Global Judging?
- Does a verified contrasting site/time event actually exist? Is the source record linkable and exportable?
- Does any terrain pipeline exist in code, or is it only documented as an intended extension?

---

## 5. QA method and release status

**Completed in this environment:** human-led visual review of four screenshots; source comparison against NASA/JPL and web performance standards; review of attached Master Prompt and earlier v2/v3/v4 plans; creation of v5 master, design blueprint, and Codex directive; automated static/structural/consistency/contrast checks summarized below when run.

**Not run:** app build, typecheck, test suite, live browser, UI click-through, Playwright screenshots of new design, real JPL ephemeris validation, NASA DEM calculations, 3D asset rendering, Vercel deployment or NASA project submission. These require the actual source runtime and/or user account.

### QA severities

`BLOCKING`: scientific falsehood, wrong release/time values, inability to submit, inaccessible main flow, broken app build.  
`HIGH`: unusable mobile chart, giant 3D loading delay, confusing site/time/route, visual regression worse than screenshot.  
`MEDIUM`: typographic inconsistency, moderate microinteraction flaw, secondary view unpolished.  
`LOW`: minor cosmetic polish.

### Recommendations by urgency

**Next execution task:** supply Codex the **actual local source repository** and the three planning files. Phase 0 source audit and stable baseline first; then implementation. Preserve R0 deployment and submission pack while rebuilding landing+Explorer as P1 UX priority. If user is in Universal Event and alone, team eligibility must be corrected independently of the site.

---

## 6. Automated plan QA output

The exact checks will be appended by the package QA script. They establish **document consistency**, not functioning product quality.

### Completed static QA summary (v5 document package)

- **50/50 automated checks passed** on the final planning package: Markdown parsability, code-fence balance, structure, cross-document science concepts, mobile contracts, challenge resource/team gate, no insecure HTTP links, key asset and route coverage, no made-up-science instructions, and source/data status language.
- **Core color pairs checked:** 21 solid foreground/background combinations from the design palette; **minimum contrast ratio 5.88:1**. This validates the *proposed opaque colors*, not actual translucent text or all user-interface states. Real WCAG conformance still requires browser tests.
- **Hourly scan arithmetic:** 35 days × 24 hours + 1 inclusive endpoint = 841 samples, consistent with current UI label if source release truly contains the full uninterrupted grid.
- **Four principal documents:** full master plan, detailed design blueprint, implementation directive, and this evidence/QA report; package also includes original user prompt/screenshots and historical v4 context for Codex.
- **Observed defects:** 10 high/critical areas documented in the audit (some further subdivided in the master plan). **Full-scope feature matrix:** 28 features with data dependencies and release tiers.
- **Not assessed:** live app QA, actual data hashes, scientific numerical tests, screenshot quality of a new implementation, production WebGL, team account eligibility, or NASA submission confirmation.

**QA interpretation:** PASS means the planning package is internally coherent and ready to hand to a code-capable agent. It emphatically does **not** mean the implementation is complete or capable of winning.
