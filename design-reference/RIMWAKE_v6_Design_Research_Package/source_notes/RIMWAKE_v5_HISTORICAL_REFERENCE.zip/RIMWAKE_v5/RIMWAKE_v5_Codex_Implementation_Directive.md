# CODEX IMPLEMENTATION DIRECTIVE v5.0 — RIMWAKE
## Radical Product & Experience Reconstruction — NOT a Cosmetic Patch

> **Give this file to Codex in the directory containing the ACTUAL, FUNCTIONING RIMWAKE SOURCE REPOSITORY, alongside:**
> `RIMWAKE_v5_Full_Product_Masterplan.md` and `RIMWAKE_v5_Design_System_and_Screen_Blueprint.md`.
>
> The screenshot files are useful visual regression references. The prior v4/v3 plans and existing science artifacts are historical source context, not evidence that planned features work.

### Your role and objective

You are an elite principal product designer, visual art director, creative technologist, React/TypeScript architect, scientific visualization developer, lunar-data engineer, and quality lead. **This is an existing application redesign and product expansion, not a greenfield toy or a documentation-only assignment.**

**The current RIMWAKE interface is unacceptable to its owner.** It uses an uninspiring beige/olive and dark-green scheme, a flat one-page architecture, miniature scientific labels, crowded/low-hierarchy controls and visually underwhelming diagrams. You are instructed to **rebuild its experience architecture and visual identity from first principles**, while preserving functioning astronomy, data, provenance and deployment capability. Refactor existing components and preserve validated scientific modules instead of replacing them with a disconnected scaffold. A mere CSS palette swap, generic landing page, stock dashboard, or addition of decorative 3D is a failure.

**Target:** an exceptionally premium, cinematic, refined, memorable NASA-data-powered lunar observatory that ordinary people can use in seconds and technical reviewers can interrogate. Think scientific exhibition plus world-class consumer-product interaction design. The landing page should feel jaw-dropping; the Explorer should feel precise and effortless. The result must be visibly and demonstrably superior to the attached screenshots.

**Product:** RIMWAKE — The Lunar Horizon Observatory. Earlier internal name: HORIZON / CAUSE — The Shadow Witness. NASA Space Apps 2026 official challenge: Lunar Landing Site Navigator.

### Non-negotiable constraints

1. **Inspect actual code and real data first.** Do not infer what is implemented from planning documents or screenshot labels. Read manifest, API/query scripts, sources, tests, deployment files, routes, state, components and current app. If the repo is absent or empty, STOP destructive work, report the blocker, and request the actual working folder; do not start an unrelated scaffold without owner authorization.
2. **Protect the last functioning release.** Make a clean checkpoint/branch and Vercel preview. Do not delete data or break P0 while changing UI. If git has uncommitted work, preserve it and report precisely; do not force reset.
3. **Full redesign, not cosmetic repair.** Replace current page structure, navigation, typographic system, color system, plots and hero presentation. Separate immersive Landing from functional Explorer and Methods. Keep clear routes and a single scientific state.
4. **Science stays truthful.** No fabricated numbers, NASA mission positions, terrain results, model validation, atmospheric effects, physical power generation or RF link. In P0, "above geometric tangent plane" is NOT an unobstructed terrain view or operational power/comms window. Terrain and robustness routes are gated until genuine independent validation.
5. **Elegant, purposeful 3D.** Use authorized NASA imagery / LRO sphere when justified; geo pins only after alignment verification; lazy-load 3D; fallback fully designed and accessible; do not drag 13MB+ mesh into initial critical path. Prefer precise 2D for actual scientific comparisons.
6. **No fictional demo content.** Real visualization values derive from immutable released data. If a story case doesn't exist, no fabricated discovery. Synthetic fixture data may exist in tests only, never production.
7. **Real QA, not assurances.** Run the app, capture actual screenshots, test interactions and inspect the results. Report commands, logs, pass/fail and actual blockers. Do not claim 'pixel-perfect', 'scientifically validated', 'deployed' or 'submitted' without evidence.
8. **Time-aware shipping.** Protect public preview, release and submission materials before any speculative heavy feature. Do not spend the remaining hackathon on a feature that leaves a broken site.
9. **Respect source rights and AI declaration.** NASA source/asset credits and participant-facing AI tool disclosure; do not suggest NASA endorsement or use NASA marks as product logo.

---

## PHASE 0 — AUDIT AND SNAPSHOT (FIRST ACTION, NOT OPTIONAL)

1. Print project root, git status/branch, commit ID, package scripts, actual routes, data releases and source files. Inspect frontend architecture, scientific scripts, tests, dependencies and Vercel config.
2. Read provided v5 master plan and design blueprint. Consult prior v4/v3 only to recover historical scope and scientific assumptions. Establish which current features actually work.
3. Run existing install/build/test commands without unrelated migrations. Start app locally; capture 1440×900, 768×1024, 390×844, 360×800 screenshots of current `/` and core interactions, using Playwright or available browser instrumentation. Record console errors and assets loaded.
4. Create `docs/UX_REDESIGN_AUDIT.md`: screenshot-specific severity, task friction, colors, typography, navigation, chart behavior, active scientific model, data validation status, and full feature inventory categorized `working / defective / partial / missing / scientifically blocked`. Cite exact filenames and commands.
5. Create a protected `baseline-rimwake-v4` tag/branch or equivalent reproducible checkpoint and preserve existing public release. If creating a tag would rewrite existing history or conflict, choose safe alternative and record it.
6. Verify actual source/landing coordinates and visibility model. The provided screenshots show `Odysseus / IM-1`, `Athena / IM-2`, `0 km above reference ellipsoid`, `geometric horizon · terrain excluded`, 35-day hourly scan and 10-minute detail. **Confirm actual code and source data**; don't assume these labels validate the calculations.

**Phase 0 deliverable:** one honest audit + frozen baseline + real screenshots. Continue into product implementation immediately afterward unless blocked by missing code.

---

## PHASE 1 — DESIGN SYSTEM AND ROUTE RECONSTRUCTION

Implement the canonical direction **MIDNIGHT LUNAR OBSERVATORY** defined in the blueprint.

### Visual standard

- Absolutely abandon old beige/olive/forest-green styling.
- Design tokens: background `#060917`, canvas `#0C1528`, elevated `#111F35`, text `#F6F8FC`, supporting `#B3C0D6`, Sun `#FFD18D`, Earth `#74CDF4`, simultaneous geometric `#C0A8FF`, error `#FF8E98`.
- Use Space Grotesk heading, Inter body, IBM Plex Mono data with controlled typography, readable labels, elegant modular type scale, *not* 9px all-caps panels.
- Refined spacing, editorial compositions, bespoke instrument graphics, beautiful vector/typographic details and high-quality lunar texture. No generic repeated rounded-card grids, stock SaaS hero, uncontrolled neon/glassmorphism, or random particles.
- Contrast target WCAG 2.2 AA. Never rely on color alone for scientific state. Input/control targets generous and keyboard reachable.
- This palette is a starting contract. Improve it only after screenshot-driven design evaluation and record the replacement tokens with contrast measurements; do not drift back to muted olive/paper.

### Information architecture

Implement actual working routes and navigation according to master plan:

`/` landing, `/explore` flagship, `/investigations` and case route for genuine cases only, `/methods`, `/about`. Conditional `/cause/:caseId` and `/robustness/:caseId` gated by data/validation flags. Add a designed 404.

Landing is **not** the entire instrument. Explorer is **not** a marketing scroll page. Global nav and CTA consistently lead to a genuine comparison. Persist site/time/model on route navigation.

### Deliverables

Create/update `docs/PRODUCT_MASTERPLAN.md` to reflect actual code findings, `docs/DESIGN_SYSTEM.md`, typed shared UI primitives, route skeleton, data release flags, new layout shell. **Do not spend the entire task writing Markdown; proceed to working code.**

---

## PHASE 2 — BUILD THE JAW-DROPPING LANDING EXPERIENCE

Create a genuinely art-directed cinematic homepage:

- Full-height first viewport with a breathtaking, correctly credited lunar visual, carefully controlled side lighting, oversized but elegant typographic story, prominent `Enter the Explorer`, restrained secondary action, navigation and concise provenance.
- Use NASA [SVS CGI Moon Kit](https://svs.gsfc.nasa.gov/4720) 2K lunar texture (~447KB documented) on a custom globe if the repository/tooling permits. NASA [SVS Moon Models](https://svs.gsfc.nasa.gov/14959/) are optional but heavy; don't gate first paint on 13.2MB. Preserve legitimate asset attribution.
- Scene can be visually illustrative but must not claim site/time-specific physical accuracy unless 3D positions, lunar frames and time are verified. No made-up landing markers or simulated sunlight sold as observation.
- 3–5 deliberately paced sections: Hero → Why lunar horizon matters → How site/time comparison works → One real sourced observation → Evidence + Launch. Use a few sophisticated scroll/motion reveals, no endless cards.
- Hero scene loads progressively; provide an equally beautiful authored static fallback and `prefers-reduced-motion` behavior. Navigation and CTA work immediately.

**Visual acceptance:** screenshot at 1440×900 would impress a premium product designer; screenshot at 390×844 remains composed and readable; no overflowing large text, invisible CTA, or gratuitous blank viewport.

---

## PHASE 3 — REBUILD THE FLAGSHIP EXPLORER EXPERIENCE

### Command hierarchy

A clear, persistent site/time command bar with Site A, Site B, swap, synchronized UTC, sample step, supported-event navigation and release/model badge. Include source-grounded site category and observer model, rather than burying it as microscopic footnote.

### Primary scientific stage

Design a large, breathtaking **paired horizon visualization** (not two tiny unlabeled green circular charts in a huge black box). Prefer a physically intuitive local horizon strip or calibrated sky instrument with common axes, bright but restrained Sun/Earth celestial glyphs, below-horizon ghost treatments, readable 0° reference, azimuth/elevation measurements, spatial context and accessible numeric equivalents. SVG/2D is the numerical source of truth. Use selective 3D for context, not to replace math.

### Insight and comparison

An editorial **Observation / Difference** rail that clearly says what is visible, below, boundary or unknown for both sites and explains limits. Compute all text from actual selected site/time/model/release records. If both sites are similar, state similarity, not a manufactured dramatic contrast.

### Horizon Loom reconstruction

Replace dark, under-annotated color strips with a legible time investigation instrument. Six source-linked tracks (Sun/Earth/Both × A/B), calibrated UTC day/hour ticks, cursor, event brackets, legend with noncolor encoding, on-hover and keyboard access, tabular equivalent, obvious hourly versus 10-minute mode status. All controls read the same store; no synthetic interpolated readings.

### Evidence drawer

Make science trust first-class: this observation; source & retrieval timestamp; exact site/observer assumption; datum; model; sampling; run/release ID; validation status; limitations. Contextual evidence buttons beside important claims. Keyboard focus return, Escape and mobile bottom-sheet behavior are mandatory.

### Responsive architecture

Desktop A/B simultaneously; tablet stage + rail reorganized; mobile one-site-at-a-time with persistent two-site summary and a tab switcher, full-sized charts, UTC controls, no horizontal overflow. Everything works touch and keyboard; 3D disabled does not impair function.

**Non-negotiable tests:** swapping sites does not change time, time selection updates plot/readout/loom/evidence together, negative elevations remain readable, missing data remains `unknown`, URL restores state, app can refresh direct `/explore` URL on Vercel.

---

## PHASE 4 — STORY, 3D AND SCIENTIFIC EXTENSION

**Order matters:** Don't start advanced terrain science until Home/Explorer passes screenshot and regression QA.

1. Build **guided investigation** from source-validated event manifest. Five stages: Witness → Compare → Explain → Change → Verify. If no genuine contrasting case, use factual observational story or hide case gallery.
2. Add lazily loaded **3D lunar globe** in home/site-context view, tested with known coordinate-frame transformations before any site markers are used. Narrative orbital movement must be visually marked as illustration unless physically accurate.
3. Add **Cause Laboratory** only after validated terrain source, datums, nearby and far-field coverage, skyline/raycast tests and independent evidence. Display obstructing terrain only when computed, with bearing/distance/angle, coverage status and `unknown` when appropriate.
4. Add **Robustness Laboratory** only with true recomputed 1m/5m above-local-terrain observers and supported alternative DEM runs. `Model agreement` ≠ probability of real visibility.
5. Source-grounded exports and reproducible permalink are valuable after core is stable. Avoid ML/chatbot/extra dashboards.

**Scientific release gate:** maintain `docs/SCIENCE_STATUS.md` with status of each model and input, exact DEM frame, JPL query settings, validation tests, source URL and run hash. No verified flag from visual QA alone.

---

## PHASE 5 — ITERATIVE VISUAL QA AND ENGINEERING VERIFICATION

Mandatory **five complete rounds** as time permits, with at least three before any production promotion:

**Round 1 — Composition.** Capture actual Home, Explorer first viewport, Horizon Loom, Evidence Drawer at 1440×900, 768×1024, 390×844, 360×800. Review dominance, layout, typography, colors, axis clarity, whitespace, imagery. Write top 5 defects and fix them.

**Round 2 — Interaction.** Mouse/touch/keyboard navigate site A/B, time, event, evidence, route, back, share link. Test all controls actually do what their labels say. Verify one canonical selected sample. Check focus, reduced motion, 3D fail fallback and no hover-only access.

**Round 3 — Scientific visual integrity.** Release values match numerical cards, cursor, plots and evidence. Exercise negative elevation, boundary, unknown, off-coverage terrain, 359/0 azimuth wrap, two-site similar outcome. No invented event times, power or RF promises.

**Round 4 — Product artistry refinement.** Reinspect before/after composites at matching viewport; adjust hero Moon crop, type hierarchy, alignment, microinteractions, 3D, meaningful transitions, evidence placement. Remove generic card patterns and underdesigned empty regions.

**Round 5 — Release verification.** Run `npm run build` (or actual script), `npm run typecheck` if defined, unit tests, Playwright navigation + screenshot tests, axe accessibility, throttled browser/performance and Vercel preview in private window; preserve test output. If commands don't exist, implement small minimal tests when reasonable or report NOT RUN, never invent test success.

Use score rubric from Design Blueprint: >85/100 internal target with no category <3/5, and all severity-0 correctness/accessibility blockers resolved. Scores must be evidence-backed; do not assign numbers without screenshots and defined criteria.

---

## PHASE 6 — COMPETITION-READY RELEASE

1. Preserve the existing deployable `main` and build improved preview on separate branch.
2. Verify challenge-specific NASA Resources-tab dataset is actually used; exact URL and mapping. Do not assume all NASA sources qualify automatically.
3. Read current 2026 submission guide and user team's event/team restrictions; Universal Event Global Judging reportedly requires two members; do not assert their roster.
4. Prepare concise ≤30-second demonstration OR ≤7 slides according to 2026 GO Team guidance; check actual portal, public links, permissions and English description. Avoid showing conditional unbuilt features in demo.
5. Make AI-tool usage and external asset/rights disclosures complete. No claim of NASA endorsement.
6. Test anonymous live Vercel homepage, direct `/explore` refresh, mobile and data/source links. Produce release SHA and QA report.
7. Ask human owner to complete account-only actions when necessary. Do not claim submission unless its actual status is verified. Roll back to protected working release if redesign can't pass essential tests before deadline.

---

## REQUIRED OUTPUT AFTER EACH PHASE

Keep a compact, factual log:

- **Changed files/commits** (paths and SHAs).
- **Observed functionality** with working URLs and scenario.
- **Science used:** which data release, what models supported, level of numerical validation.
- **Screenshots:** filenames, viewport, actual app route and test conditions.
- **Commands executed:** exact command, exit code, summary; don't silently skip failing tests.
- **Status:** `PASS`, `FAIL`, `BLOCKED`, `NOT RUN` for each quality gate.
- **Open issues:** severity, responsible component, next action.
- **Comparison to old UI:** concrete differences observed in screenshots, not claims like "premium now".

### Final delivery contract

Provide these actual outputs in the repository:

`docs/PRODUCT_MASTERPLAN.md`, `docs/DESIGN_SYSTEM.md`, `docs/UX_REDESIGN_AUDIT.md`, `docs/SCIENCE_STATUS.md`, `docs/FEATURE_STATUS.md`, source ledger/credits, working routes/components, real test artifacts, production or preview deployment guidance, screenshot before/after contact sheet, precise remaining-feature roadmap.

**Do not stop after writing plans. Implement the redesigned experience, run it, inspect it, improve it, verify it.** If tools or time limit completion, deliver the **best functioning incremental UI and exact incomplete work inventory** instead of an imaginary completion statement.

### Final design directive

**Make RIMWAKE extraordinary in its presentation, understandable at first glance, and completely honest about what its scientific model has actually computed.** Scientific credibility and visual craft must amplify each other—not compete.
